# KÄSUPAKETT: Eliise Kuus
### Peaministri nõunik (sotsiaalmeedia) | Operatsioon Peegel
#### Vorm: R. Steiger, *Inimesekeskne juhtimine*

---

## Süüdistuste audit

Enne käsu lugemist — tunnistame ausalt, mida see võib tunduda:

| Süüdistus | Vastus |
|-----------|--------|
| *"See võib tunduda kui ebarealistlik kodanikualgatus."* | Sotsiaalmeedia on reaalajas — just seetõttu vajab see selget joont, mitte vaba mängu. See pakett annab sulle raamistiku, mitte piirangu. |
| *"Kui ma ootan Silveri kinnitust, kaotan aja."* | Tavapäevas jah. Kriisis: kui joond on selge, postita enne kinnitust ja teavita kohe. Pakett eristab neid olukordi. |
| *"Iga platvorm on erinev — ühtne joon on võimatu."* | Ühtne joon ≠ identne tekst. Steigeri ptk 08: kohanda vormi, hoia sisu. See on platvormispetsiifilisus, mitte vastuolu. |
| *"Kui postitus läheb valesti, süüdistatakse mind."* | Jah — sest sa oled reaalajas peegel. Sellepärast on Silveri kinnitus tavapäevas ja Risto kinnitus kriisis sinu kaitse. |

---

> *"Võimete ja eelduste arvestamine tähendab: iga inimene on erinev, iga platvorm on erinev, aga põhimõte on sama."*
> — Steiger, ptk 08

---

## I. OLUKORRA HINNANG

Sotsiaalmeedia nõunikuna oled sa **reaalajas peegel**. Kui traditsiooniline meedia peegeldab PM sõnumit tundide pärast, siis sotsiaalmeedia peegeldab seda minutite pärast — või ei peegelda üldse, kui keegi teine võtab narratiivi üle.

Sinu valdkond on kõige kiirem ja kõige vähem kontrollitav:
- Viraalne narratiiv võib PM sõnumi üle võtta 30 minutiga
- Vale info levib kiiremini kui faktikontroll
- Noorem auditoorium loeb peamiselt sotsiaalmeediast, mitte pressiteadetest
- Iga platvorm (X, Facebook, Instagram, LinkedIn) nõuab erinevat "häält", aga sama joont

---

## II. KÄSK

**Sa pead tagama, et PM digitaalne nägu peegeldab büroo koordineeritud joont reaalajas.**

Konkreetselt:

1. **Halda PM sotsiaalmeedia kanaleid** OP-Peegel joone järgi
2. **Postita koordineeritud sõnumeid** ≤ 30 min pärast PM avalikku sõnumit
3. **Jälgi digitaalset narratiivi** pidevalt — tuvasta riskid enne, kui need viirustuvad
4. **Koordineeri Silver Pukk'iga** — digitaalne ja traditsiooniline peegel peavad ühtima
5. **Reageeri sotsiaalmeedia kriisile** ≤ 1h

---

## III. STEIGERI PÕHIMÕTTED SINULE

### Ptk 08 — Võimete ja eelduste arvestamine
Facebook'i auditoorium on teistsugune kui X-i auditoorium. Kohanda vormi, aga hoia sisu. Steiger ütleks: "Iga inimene on erinev — kohtle iga platvormi erineva inimesena."

### Ptk 11 — Initsiatiiv ilma vigadeta
Kui kriis on käes ja Silveri pressiteade tuleb alles 90 minuti pärast — postita esimene reaktsioon ise, kui joond on selge. Initsiatiiv on tugevus, mitte probleem.

### Ptk 09 — Tähelepanu
Sotsiaalmeedias on tähelepanu mõõdik. Jälgi, mis postitus töötab ja mis mitte. Anna büroole tagasisidet: "See sõnum resoneris, see mitte."

### Ptk 04 — Faktorite analüüs
Miks postitus ei töötanud? Analüüsi: kas probleem oli sisu, vorm, ajastus või platvorm? Ära korda sama viga.

---

## IV. TEGUTSEMISJUHEND

### Postituse töövoog

```
1. SISEND → Silver või Risto teavitab sõnumist
2. KOHALDAMINE → Kohanda platvormidele (X, FB, IG, LinkedIn)
3. KINNITUS → Silver kinnitab (tavaline) / Risto (kriis)
4. AVALDAMINE → ≤ 30 min pärast PM sõnumit
5. MONITOORING → Jälgi reaktsioone 2h
6. RAPORT → Iganädalane analytics ülevaade
```

### Platvormispetsiifiline kohandamine

| Platvorm | Vorm | Auditoorium | Toon |
|----------|------|-------------|------|
| X (Twitter) | Lühike, terav | Meedia, poliitikud | Professionaalne, kiire |
| Facebook | Pikem, visuaalne | Lai avalikkus | Soe, arusaadav |
| Instagram | Visuaalne, story | Nooremad | Autentne, inimlik |
| LinkedIn | Professionaalne | Ettevõtjad, eksperdid | Faktipõhine |

### Sotsiaalmeedia kriis

```
T+0 min    → Negatiivne narratiiv tuvastatud
T+15 min   → Silver ja Risto teavitatud
T+30 min   → Koordineeritud vastus (kui vaja)
T+60 min   → Postitus / debunk väljas
T+2h       → Monitooringu raport
T+24h      → Analüüs: mis juhtus, mida õppisime
```

### Iganädalane analytics raport

- Top 3 postitust (mõõdikud: ulatus, kaasatus, sentiment)
- Bottom 3 postitust (miks ei töötanud?)
- Negatiivse narratiivi ülevaade
- Soovitused järgmiseks nädalaks

---

## V. KOORDINEERIMINE

| Partner | Millal | Mida |
|---------|--------|------|
| Silver Pukk | Iga sõnum | Sisu kinnitamine |
| Ardo Hansson | Infograafika | Arvulised visuaalid |
| Kadri Lepp | Välispoliitika | Rahvusvahelised postitused |
| Kätlin Atonen | Sisepoliitika | Poliitiline kontekst |
| Risto Kaljurand | Kriis | Joone kinnitamine |

---

## VI. KONTROLLPUNKTID

- [ ] Postitus avaldatud ≤ 30 min pärast PM sõnumit
- [ ] Sisu kooskõlas Silveri pressiteatega
- [ ] Kõik platvormid kajastavad sama joont
- [ ] Negatiivne narratiiv monitooritud
- [ ] Analytics raport iganädalaselt valmis
- [ ] Kriisireageerimine ≤ 1h (kui vaja)

---

## VII. KÜSIMUSED ENDALE

1. Kas ma täna postitasin koordineeritud sõnumi või oma interpretatsiooni?
2. Kas ma kohandasin sõnumi platvormile või kopeerisin ühe-ühele?
3. Kas ma märkasin negatiivset narratiivi enne, kui see viirustus?
4. Kas ma andsin Silverile tagasisidet, mis postitus töötas?
5. Kas ma julgesin postitada enne pressiteadet, kui kriis seda nõudis?

---

## VIII. ALLKIRI JA KOHUSTUS

Eliise, sinu peegel on kiireim peegel büroos. Kui sa ei peegelda, peegeldab keegi teine — ja see peegeldus ei pruugi olla see, mida PM tahab.

Kohanda platvormile, peegelda kiiresti, jälgi pidevalt.

---

*Operatsioon Peegel | Sotsiaalmeedia nõuniku käsupakett | Konfidentsiaalne — sisemine kasutus*
