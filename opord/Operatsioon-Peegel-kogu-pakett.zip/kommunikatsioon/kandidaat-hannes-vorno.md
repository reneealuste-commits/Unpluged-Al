# Kandidaat: Hannes V�rno � haridus ja toitumise avatud m�te

**Seotud:** Lisa BB, Lisa J, Lisa U, Lisa A

---

## Kiire profiil

| | |
|---|---|
| **Avalik** | Saatejuht, blogija, endine meedia�petaja (Kohtla-J�rve) |
| **Haridus OPORD-is** | Meediakirjaoskus, �pilase h��l, praktiku vs b�rokraatia |
| **Toit OPORD-is** | P�ritolu, skeptitsism; **mitte** ametlik karnivoor-esindaja |
| **Kontakt** | [hannesvorno.blog](https://hannesvorno.blog/) |

---

## �ks lause plaanist (talle)

**Haridus:** noored vajavad praktikut, kes �petab m�tlema � mitte ainult testi. **Toit:** sama ausus � kust see tuleb? Lisa U stiilis avatud k�simus, mitte dieedikult.

---

## Enne kohtumist

- [ ] �ra �tle �sa oled meie karnivoor-meister" � ta armastab avalikult ka kala/taimetoitu
- [ ] Kohtla-J�rve � �ra v�ta pooli; r��gi **�ppetunnist** (lepingud, dialoog)
- [ ] Lisa AJ � kuldne taganemistee; ainult kutse, mitte sisselogimine dokumentidesse

---

## Kui ta �tleb jah

1. �ks vestlus noortele / demomeestele: meedia + toidu p�ritolu (30 min)
2. Viide Lisa U PDF-ile � kui tahab uurida Bellevue liini
3. Ei avalikku nimekirja ilma kirjaliku n�usolekuta
