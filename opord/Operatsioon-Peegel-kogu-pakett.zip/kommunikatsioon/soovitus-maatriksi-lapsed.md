# Soovitus: �Maatriksi Lapsed� � k�su lisa k�igile

**Episood:** Ava Oma Silmad & Ajuloputus S4 #10 � *Maatriksi Lapsed*  
**Kuup�ev:** 3. m�rts 2026 � ~1h 20 min  
**Saatejuhid:** Katrin Lucas + Ajuloputus  
**Seotud:** Lisa K (Katrin Lucas), Lisa P, Lisa W, Lisa H, Lisa S, PEEGEL_TEE_C

> **Reegel:** See on **valikuline** kuulamine � mitte k�sk ega doktriin. **Eesti keel primaarselt.** OPORD-i hoiak: *ava silmad, vali ise, kriitiliselt m�tle.*

---

## Mida episood tegelikult k�sitleb (allikad: Acast, Apple Podcasts, hooaja kontekst)

Ametlik kokkuv�te:

- Mida **s�steem** (�maatriks�) teeb **lastega** � ja mida lapsed tegelikult vajavad.
- T�iskasvanud hoitakse **elluj��misre�iimis** � siis pole aega m�rgata, mis lastega toimub.
- **Meie �lesanne:** hoida ja kaitsta lapsi � mitte ainult s��distada s�steemi, vaid n�ha, kus **sina** saad muutust luua (pere, meeskond, enda sisemaailm).

Hooaja kontekstist (S4 #6, #9 � samad teemad, erinev nurk):

| Teema | Kuidas see Peegliga haakub |
|-------|---------------------------|
| Lapsep�lve trauma, hirm vs armastus | Lisa P, Lisa S � keha m�letab enne m�istust |
| N�rvis�steem ja peidetud trauma | Lisa H, Lisa P � turvalisus enne loogikat |
| Laps kui kompetentne olend | Lisa W (Montessori) � austus, tempo, vabadus |
| Vanema/juhi kaitseroll | Lisa Q �4 (kata ja liigu), Extreme Ownership |
| Algoritm ja t�helepanu | Lisa AU � platvormid; lapsed esimeses l��gis |

**Mida episood EI ole:** OPORD-i ametlik seisukoht. M�ned teised Lucas/Ajuloputuse osad l�hevad OPORD-i raamist v�lja (nt etniline/v�imu�iguslik vanden�uteooria � vt Lisa AU). Seda episoodi soovitame **laste, trauma ja kaitse** nurga alt.

---

## Lingid (kopeeri k�sku)

| Kanal | Link |
|-------|------|
| **Acast** (otse episood, ET) | https://shows.acast.com/avaomasilmad/episodes/ee-jata-navigatsioon-vahele-loomine-avataripilt-ava-oma-silm |
| **Katrin Lucas** (podcasti leht, ET) | https://katrinlucas.com/podcast/ |
| **Apple Podcasts (Eesti)** | https://podcasts.apple.com/ee/podcast/ava-oma-silmad-podcast/id1541890084 |
| **YouTube** (video, teisej�rguline) | https://www.youtube.com/@AJULOPUTUS � otsi �Maatriksi Lapsed� |

---

## Kutsuv tekst e-kirja jaoks (�ldine)

```
Enne kui materjaliga edasi l�hed � �ks valikuline soovitus (~1h 20 min):

?? Ava Oma Silmad & Ajuloputus S4 #10 � �Maatriksi Lapsed"

Kus s�steem tabab k�ige enne lapsi � ja miks t�iskasvanud elluj��misre�iimis ei m�rka seda. R��gib turvalisusest, kohalolust ja kaitsest: mida lapsed tegelikult vajavad, mitte mida algoritm neile pakub. Extreme Ownershipi vaimus: mitte ainult s��distada s�steemi, vaid n�ha, kus sina saad ise muutust luua � pere, meeskonna v�i enda sees.

Kuula: https://shows.acast.com/avaomasilmad/episodes/ee-jata-navigatsioon-vahele-loomine-avataripilt-ava-oma-silm
YouTube (video): https://www.youtube.com/@AJULOPUTUS � otsi �Maatriksi Lapsed"

See ei ole k�sk. See on kutse avada silmad ja valida ise.
```

---

## Kohandatud avaus (paketi j�rgi)

### P1-C-PERE (pere, kool, Montessori, Waldorf)

> Kui su roll on **laste** v�i **pere** kaitse � see episood on sinu jaoks esimene valikuline kuulamine enne PEEGEL_TEE_C-d.

### P1-A-KRIIS (isa, taastumine, meeste ring)

> Kui oled ise elluj��misre�iimis � episood aitab m�ista, miks lapsed (ja sina) vajavad k�igepealt **turvalisust**, mitte loogikat.

### P1-F-JUHT (juht, koolitaja, CR)

> Juhi vaatenurgast: kaitse enne tulemust. Meeskond ja pere on sama loogika � kui keegi on elluj��misre�iimis, ta ei n�e plaani (Lisa AT).

### P0-TUUM / muu

> �ldine teadlikkuse kanal � sobib neile, kes tahavad s�gavamat konteksti enne OPORD-i.

---

*Lisa: kommunikatsioon/soovitus-maatriksi-lapsed.md � uuenda k�ske: `python3 scripts/write_osalejate_kask.py`*
