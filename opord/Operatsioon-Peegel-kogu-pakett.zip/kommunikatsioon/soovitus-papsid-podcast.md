# Soovitus: Papsid.ee Podcast � k�su lisa isadele ja pererindele

**Podcast:** PAPSID.EE PODCAST  
**Saatejuhid:** Kristo Tuurmann & Illimar Pilt  
**Keel:** eesti  
**Seotud:** Lisa D (Tugev isa), Lisa H, Lisa P, Lisa Q (NVC), PEEGEL_TEE_A, PEEGEL_TEE_C, papsid.ee

> **Reegel:** Valikuline kuulamine � mitte k�sk. **Eesti keel primaarselt.** Iga episood = �ks k�simus: *�Mida ma �ppisin ja kuidas rakendan seda t�na oma perega?"*

---

## Miks see sobib Peegli isarindele

| Peegli tuum | Papsid.ee |
|-------------|-----------|
| **Extreme Ownership** | V�ta vastutus oma rolli eest � mitte s��distada partnerit ega s�steemi |
| **NVC** (Lisa Q) | Aus, hinnanguta suhtlus perega � praktilised vestlused, mitte tabu |
| **Body Keeps the Score** (Lisa P, S) | Kuidas varasemad kogemused m�jutavad isa-olekut |
| **Lisa H** | Isa kriisis � ausad lood, mitte moraliseerimine |
| **Lisa W** | L�hedus lastega, kohalolek |

Podcast on **praktiline ja toetav** � igap�evased v�ljakutsed, paarisuhe, eneseareng, trauma ja vastutus **meeste vaatevinklist**.

---

## Lingid

| Kanal | Link |
|-------|------|
| **Koduleht** | https://papsid.ee/podcast/ |
| **Apple Podcasts** | https://podcasts.apple.com/ee/podcast/papsid-ee-podcast/id1768003452 |
| **Spotify** | otsi �Papsid.ee Podcast" |
| **Papside laager** | https://papsid.ee/papside-laager/ |
| **Koolitused** | https://papsid.ee |

---

## Kutsuv tekst e-kirja jaoks

```
Enne kui materjaliga edasi l�hed � �ks valikuline soovitus (isa / pere rinne):

KUULA: Papsid.ee Podcast � Kristo Tuurmann & Illimar Pilt

Isaduse teemad ausalt: vastutus, suhe, trauma, kohalolek lastega. Sobib h�sti Extreme Ownershipi, NVC ja Body Keeps the Score loogikaga � praktiline, mitte lobisemine.

Kuula: https://papsid.ee/podcast/
Apple Podcasts: https://podcasts.apple.com/ee/podcast/papsid-ee-podcast/id1768003452

P�rast episoodi �ks k�simus endale: �Mida ma �ppisin ja mida teen t�na teisiti?"

See ei ole k�sk. V�ike samm t�na on tugevam kui t�iuslik plaan homme.
```

---

## Kellele k�sus (paketi j�rgi)

| Sidepakk | Soovitus |
|----------|----------|
| **P1-C-PERE** | Esimene valikuline podcast enne PEEGEL_TEE_C |
| **P1-A-KRIIS** | Isa p�hjas � Lisa H + �ks Papsid episood |
| **P1-F-JUHT** (noored) | Taneli rinne � isa roll enne algoritmi |

*Haridust��tajatele (Waldorf, Montessori, kool): sobib ka [soovitus-maatriksi-lapsed.md](soovitus-maatriksi-lapsed.md).*

---

## Ainult kui eestikeelne ei piisa (teisej�rguline)

> **�ra soovita neid enne** [Papsid.ee](https://papsid.ee/podcast/) v�i teisi eestikeelseid kanaleid. Vt `soovitus-meedia-eesti-primaar.md`.

| Podcast | Fookus | Keel |
|---------|--------|------|
| The Dad Edge | Juhtimine, abielu, tervis | EN |
| Dad Up Podcast | Meeste areng | EN |
| The Daily Dad (Ryan Holiday) | Stoitsism, isadus | EN |

---

*Lisa: kommunikatsioon/soovitus-papsid-podcast.md � uuenda k�ske: `python3 scripts/write_osalejate_kask.py`*
