# Strateegia: eraldumine Combat Ready-st (Remo Ojaste s�num)

**Kuup�ev:** 26. juuli 2026  
**Kontekst:** Remo Ojaste SMS-kokkuv�te p�rast ~2h vestlust. Operatsioon �Peegel" tekitab CR meeskonnas emotsioone; Remole helistatakse k�simustega, mida ta ps�hholoogiliselt ei suuda hallata.  
**Soovitus:** **Path B** � selge eristamine; **reneealuste.com** / kodanikualgatus; CR-l **pole** operatsiooniga seost.  
**Seotud:** Lisa AJ (kuldne taganemistee), Lisa AY (Art of the Deal, kuldne sild), Lisa X (OPSEC), Lisa P (trauma vs �v�ta kokku").

---

## 0. Renee j�reldus (26.07) � miks eraldumine on **struktuurne**, mitte isiklik

Kui Renee �tles Remole �lahkun � mida sa tahad, et ma teen?" ja tunnistas tema stressi (�raske inimestele seletada"), vastas Remo **3�4 p�eva ultimatumiga** � domineeriv, kontrolliv. Renee s�dames: **CR on teel ette.**

| Mida inimesed n�evad | Mida nad tunnevad |
|----------------------|-------------------|
| Operatsioon Peegel (trauma, pere, keha, tasuta tuum) | �Keegi r��gib minuga" |
| Combat Ready (kallis koolitus, Extreme Ownership) | �See on �ri. See on fake." |

**See ei t�henda, et CR on vale.** See t�hendab:

1. **J�rjekord on vale** � van der Kolk / Lisa P: enne *v�ta vastutust* peab olema **turvalisus ? keha ? m�istus**. Traumatiseeritud inimene ei saa �ownershipi" osta � ta kaitseb end. S�num tundub **v�lts**, isegi kui sisu on hea.
2. **�rimudel kollideerib** � inimene, kes on p�hjas, n�eb hinda ja m�tleb: *j�lle m��akse mulle lahendust*. OPORD on **tasuta tuum**; CR on **premium**. Seos teeb kogu s�numi kahtlaseks.
3. **Remo on triggeris** � talle helistatakse, surve tuleb l�bi, ta ei oska trauma tasemel vastata. Ultimatum = **fight response** + br�ndi kaitse, mitte puhas strateegia.

> *Sa ei eita Extreme Ownershipi. Sa �tled: **vale j�rjekord, vale publik, vale br�nd sama katusel.***

**Ultimatum 3�4 p�eva:** �ra v�ta seda isiklikult. V�ta seda kui **kiirendust**, mida sa niikuinii tahtsid. Vasta 24h jooksul, mitte nelja p�eva p�rast � nii j��vad m�lemale au ja kontroll.

### Remo vastus p�rast �lahkun" (26.07 �htu) � **m�istlik, koost��**

Remo ei survestanud edasi. Ta �tles sisuliselt:

| Mida ta palub | Mida see t�hendab |
|---------------|-------------------|
| V�ta maha, et sa **ei t��ta hetkel** / **ei ole CR instruktor** | CR veeb, db/dashboard, bannerid � k�ik, kus sind CR meeskonnana n�idatakse |
| Plaan edasi: **sinu br�nd**, podcast, uus missioon | Path B kinnitatud � ta aitab *eristada*, mitte blokeerida |
| Podcasti osa: selgitame olukorda, tutvustame sinu plaani | **Kuldne sild** � �hine narratiiv, mitte avalik t�li |
| Uued kursused, Ranger handbookid jms | Sisu v�ib j��da � aga **CR lipu all mitte** |

> *See on hea tulemus. Ta ei v�idelnud. Ta andis sulle kontrolli oma kanalil ja pakkus abi br�ndi loomisel.*

**Sinu kohe tegevused (t�na�homme):**

1. CR **db/dashboard** � eemalda v�i deaktiveeri instruktori staatus
2. CR **veeb / meeskonna leht** � palu Remol v�i Priidul eemaldada profiil (v�i m�rgi �endine")
3. **Sotsiaalmeedia bio** � eemalda �Combat Ready instruktor"
4. **OPORD / materjalid** � uuenda �endine CR (2023�2026)", mitte aktiivne roll
5. Vasta Remole: n�ustun, teen �ra, podcast � jah, kui ajakava sobib

---

## 1. Remo s�numi tuum (faktid)

| Element | Mida ta �tleb |
|---------|----------------|
| **Kokkulepe (tema j�rgi)** | Usaldus sinu kavatsuse vastu; kaks teed |
| **Path A** | Combat Ready � n�uab **koordineerimist tema plaanidega** |
| **Path B** | Sinu meetod **reneealuste.com** all � n�uab **selget eristamist** |
| **Mitte l�bir��gitav** | CR lipu all on **�ks meetod: vastutus**. Emotsiooni/trauma-meetod on **teine asi**. M�lemat **CR nime all korraga ei ole**. |
| **L�bir��gitav** | *Kuidas* eristame � nimed, materjalid, kanalid |
| **J�rgmine samm** | Sinu otsuse kuup�ev; ta pakub tuge, kui valid oma tee |

---

## 2. Remo s�num � emotsionaalne lugemine (�tundub l�ksus")

Remo kirjutab **struktureeritult** (numbrid, kokkuv�te, j�rgmine samm) � see on **kontrolli** keel, mitte n�rkus. Emotsioon on t�en�oliselt allpool:

| Mida ta v�ib tunda | Miks |
|--------------------|------|
| **L�ksus** | CR br�nd (Extreme Ownership, vastutus, Jocko) on seotud sinu operatsiooniga, mis on **keha, trauma, emotsioon, pere** � vastupidine CR avalikule identiteedile |
| **�lekoormus** | Inimesed helistavad **talle**, ta ei oska vastata trauma/ps�hholoogia tasemel |
| **Kaotus kontrollist** | Path A s�num: �koordineerimine **minu** plaanidega" � ta tahab tagasi juhtimis�igust br�ndi �le |
| **Hirm maine eest** | Kui CR = �emotsiooniline operatsioon", kannatab �ri, partnerlus Echelon Frontiga, koolitusturg |
| **Vajadus olla hea juht** | �Toetan sind, kui valid oma tee" � ta ei taha olla kurjategija; ta tahab **selget raami** |

**�ra loe seda vaenlasena.** Loed seda **�riomanikuna**, kes kaitseb br�ndi ja on emotsionaalselt �lekoormatud.

---

## 3. Art of the Deal � Remo k�ik

| P�him�te | Kuidas Remo seda kasutab |
|----------|-------------------------|
| **Anchor (k�va ankur)** | �See ei ole punkt, mille �le me l�bi r��gime" � eristamine on ette otsustatud |
| **Illusioon valikust** | Path A v�i B � m�lemad viivad **eristamiseni** v�i **allumiseni tema plaanidele** |
| **Protect the downside** | CR br�nd kaitstud emotsiooniseostuse eest |
| **Deadline** | �Mis kuup�evaks j�uad otsuseni?" � survestab sind enne, kui sina valmistad |
| **Good cop** | �Toetan sind oma teel" � v�hendab konfrontatsiooni, hoiab ukse lahti |
| **Control the narrative** | Kirjalik kokkuv�te p�rast vestlust � tema versioon on esimene dokument |

**Tema n�rk koht:** ta **vajab** sinu koost��d eristamise *viisis* � ilma sinuta j��vad vanad PDF-id, ZIP-id ja lingid CR-i k�lge ja k�ned j�tkuvad.

---

## 4. Art of the Deal � sinu k�ik (soovitus)

| P�him�te | Sinu tegevus |
|----------|--------------|
| **�ra v�itle vale koha p�rast** | �ra vaidle, kas eristamine on vajalik � **n�ustu p�him�ttega** |
| **V�ta Path B** | See on see, mida sa niikuinii tahad � Remo raam sobib |
| **Maximize options** | Erista *kiiresti*; hoia isiklikud suhted Priit, Her Way jms (ilma CR liputa) |
| **Protect the downside** | �ks avalik lause + dokumentide puhastus � v�hem k�nesid talle |
| **Deliver the goods** | Anna kuup�ev (nt 48�72h esimese puhastuse jaoks) |
| **Anna talle v�it** | �Sa olid �igel � CR = vastutus. Peegel = teine kanal." |
| **Kuldne sild (Lisa AY/AJ)** | Au s�ilitav lahkumine; �ra avalikku konflikti |

---

## 5. SWOT � eraldumine Combat Ready-st (kohe)

### Strengths (tugevused)

| # | Tugevus |
|---|---------|
| 1 | **Joondub Remo mitte-l�bir��gitava joonega** � v�hem draamat, kiirem rahu |
| 2 | **OPORD juba �tleb:** kodanikualgatus, ei esinda CR/riiki (Lisa P, Lisa X) |
| 3 | **Sisuline t�de:** Peegel on trauma-teadlik; CR on Extreme Ownership � **erinevad meetodid** |
| 4 | **L�petab vale kanali:** inimesed ei peaks helistama Remole ps�hholoogia k�simustes |
| 5 | **Lisa AJ vaim:** austav eraldumine, mitte repliim |

### Weaknesses (n�rkused)

| # | N�rkus |
|---|--------|
| 1 | Kaotad CR **levituskanali** (e-pood, DocSend, koolituse m��gitoru) |
| 2 | Lisa K v�rgustikus on palju **CR-risti** � vajab uuendust |
| 3 | V�line arvamus v�ib n�ha **lahkhelid** � vajab selget s�numit |
| 4 | M�ned partnerid on CR kaudu sisse tulnud � segadus l�hiajaliselt |

### Opportunities (v�imalused)

| # | V�imalus |
|---|----------|
| 1 | **reneealuste.com** / kodanikualgatus kui selge kodu |
| 2 | Remo saab **hingata** � v�ib hiljem isiklikult toetada, mitte br�ndina |
| 3 | Puhas **infoh�gieen:** keegi ei saa �elda �CR toetab seda" |
| 4 | Trauma/pere/rindejoon s�num **ilma vastuoluta** vastutuse br�ndiga |
| 5 | Kiire otsus = **usaldus** m�lemapoolne (�ta tegi �ra") |

### Threats (ohud)

| # | Oht |
|---|-----|
| 1 | **Poolik eristamine** � PDF/ZIP/veeb j�tkab CR seost ? k�ned j�tkuvad |
| 2 | **Avalik spin** �lahkus / t�li" � vajab �htset l�hikest narratiivi |
| 3 | CR meeskonna liikmed **vaheliin** � selge sisekiri neile |
| 4 | Liiga aeglane vastus ? Remo t�lgendab kui vastuolu |
| 5 | Emotsionaalne vastus Remole ? s�vendab l�ksutunnet |

---

## 6. Soovitus: tee **kohe**, aga **puhtalt**

### 24�72 tunni plaan

| # | Tegevus | T�htaeg |
|---|---------|---------|
| 1 | **Kirjalik vastus Remole** (allpool mall) | T�na |
| 2 | **�ks avalik lause** (veeb/sotsiaalmeedia/bio) | 24h |
| 3 | **Dokumentide puhastus** � eemalda �Combat Ready toetab / partner" kui implikatsioon | 48h |
| 4 | **Lisa K / OPORD** � CR rollid ? �isiklik koost�� v�imalik, br�nd ei seo" | 72h |
| 5 | **Sisekiri CR meeskonnale** (Remo saadab v�i sina Priiti kaudu) | 48h |

### Avalik �ks lause (mall)

> *Operatsioon �Peegel" on **Renee Aluste kodanikualgatus**. See **ei ole** Combat Ready O� toode ega koolitus. K�simused operatsiooni kohta: [kontakt]. K�simused koolituse kohta: combatready.eu.*

### Sisekiri CR meeskonnale (mall)

> *Peegel liigub eraldi kanalile. See ei ole CR eba�nnestumine � see on **br�ndi selgus**. CR = vastutus ja juhtimiskoolitus. Peegel = pere, trauma-teadlikkus, kodanik. Palun suuna operatsiooni k�simused Renee poole, mitte Remo telefonile.*

---

## 7. Kiire SMS (kui juba �tlesid �lahkun" ja ta andis ultimatumi)

> Remo � t�nan kokkuv�tte eest. **Otsus on tehtud: Path B.** Peegel j��b minu kanalile, CR-l sellega seost ei ole. Sa olid �igel � CR = vastutus, minu t�� = teine asi (keha, pere, trauma). **28.07** avalik lause + esimene puhastus; **31.07** t�ielik kontroll. Aitan FAQ-ga, et k�ned ei tuleks sinule. Ait�h aususe eest.

*Sa ei pea ootama 3�4 p�eva. Ultimatum on tema stress, mitte sinu t�htaeg. Vasta 24h jooksul � selgelt, ilma vaidluseta.*

### Vastus Remo koost��pakkumisele (p�rast tema �v�ta maha" s�numit)

> Remo � m�istlik ja aus. **Teen �ra:** v�tan CR-st maha (db, bannerid, k�ik kus n�en). **Path B kinnitatud.** Podcast � jah, hea m�te; paneme paika, kui puhastus tehtud. Uus missioon: Operatsioon Peegel / kodanikualgatus � trauma enne vastutust. Ait�h, et aitad br�ndi eristada, mitte blokeerida.

---

## 8. Soovitatav vastus Remole (pikem SMS / e-kiri � kopeeri)

> Remo, t�nan kokkuv�tte eest � loen seda samamoodi.
>
> **Minu otsus on Path B:** Operatsioon �Peegel" j��b **minu kanalile** (reneealuste.com / kodanikualgatus). **Combat Ready-l sellega seost ei ole** ja ma ei kasuta CR nime, materjale ega kanaleid selle operatsiooni jaoks.
>
> Sa olid �igel: **CR lipu all on vastutuse meetod** � see on teie br�nd. Minu t�� on **teine asi** (keha, pere, trauma-teadlikkus) � mitte halvem, aga **eraldi**.
>
> **J�rgmine samm minult:**
> � **[kuup�ev, nt 28.07.2026]** � avalik lause + esimene dokumentide puhastus (nimed, lingid, ZIP-id).
> � **[kuup�ev, nt 31.07.2026]** � t�ielik eristamise kontroll (Lisa K, OPORD, PDF).
>
> **Lepime kokku koos:** kuidas edastada inimestele, kes on juba segaduses � �ks l�hike FAQ, et k�ned ei tuleks sinule.
>
> Ma hindan toetust. Ait�h aususe eest.

---

## 9. Mida mitte teha

- �ra vaidle, kas emotsioon on �halb" v�i vastutus on �parem".
- �ra j�ta poolikut � see j�tkab k�nesid Remole.
- �ra avalikusta Remo �n�rkust" v�i �l�ksu".
- �ra seo lahkumist v�idukaks narratiiviks � **kuldne sild** m�lemale.

---

*Strateegia � eraldumine Combat Ready. Operatsioon �Peegel". Konfidentsiaalne kuni avaliku lause avaldamiseni.*
