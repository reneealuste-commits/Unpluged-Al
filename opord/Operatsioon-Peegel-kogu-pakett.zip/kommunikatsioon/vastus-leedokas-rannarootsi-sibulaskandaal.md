# Vastus / kommentaar � Leedokas: Rannarootsi �sibulaskandaal" (Facebook)

**Allikas:** [Facebook video / Reel � Leedokas](https://www.facebook.com/share/v/184FwtCw2h/) (reel `901611742409117`)  
**Kontekst:** Rannarootsi reklaam (sibulad) ? poliitiline �rahvusk�simus"; Mihhail K�lvart ja Yana Toom s��distatud venekeelsete inimeste solvumise �hutamises poliitilise kasu nimel.  
**Seotud OPORD-is:** Lisa AN (venekeelne kanal, inimesekeskne), Lisa P (valideerimine, trigger), Raamat 01 (infoh�gieen), Lisa BD (NVC � keegi ei �tle sulle, millal solvuda), Lisa T (poliitilised vektorid).

**Toon:** aus, mitte kampaania � kriitiline m�tlemine, mitte uus kultuuris�da.

---

## Video tuum (kokkuv�te)

Leedokas �tleb eelk�ige venekeelsetele, aga ka eestimeelsetele s�pradele:

1. **�rge laske poliitikutel end solvuma �hutada**, kui tegelikult pole p�hjust.
2. Tavalisest reklaamist tehakse **kunstlik skandaal** � inimestele �eldakse ette, *millal* solvuda ja *kelle* peale vihane olla.
3. Video **ei ole** venekeelsete inimeste vastu � vastupidi, hoiatab **manipulatsiooni** eest.
4. Kui solvusid reklaami peale, aga pole kremlimeelne � **kasutati sind poliitiliselt �ra**.

---

## Operatsiooni positsioon (Peegel)

| K�simus | Vastus |
|---------|--------|
| Kas reklaam ise on �s��di"? | �ra otsusta emotsiooniga � **vaata allikat ja konteksti** (Raamat 01). |
| Kas �ks keel = �ks poliitika? | **Ei.** Lisa AN: venekeelne sihtr�hm ? �ks blokk; inimene on inimene. |
| Kes v�idab, kui sa vihastad? | Tavaliselt **mitte sina** � vaid see, kes jagab �hiskonda (infoh�gieen). |
| Mida teha? | **Ava silmad:** kes �hutab solvumist? kes kasu saab? kas sul endal on p�ris p�hjus? |

> *Riigikaitse algab kodus � ka siis, kui keegi �ritab sind �hutada v��rastama naabrit reklaami p�rast.*

---

## Soovitatav vastus (Facebooki kommentaar � kopeeri)

> T�pselt see on **infoh�gieen**: tavalisest reklaamist tehakse skandaal, sest keegi tahab, et sa **solvuksid enne**, kui sa k�sid *miks*.
>
> Operatsioon �Peegel" ei �tle, et sa ei tohi kunagi solvuda. Me �tleme: **�ra lase �elda ette**, millal ja kelle peale � eriti kui kasu saab poliitika, mitte pere ega riik.
>
> Venekeelne naaber ei ole automaatselt vaenlane. Eestikeelne poliitik ei ole automaatselt kangelane. **K�si: kes v�idab, kui ma vihastan?**
>
> Ait�h Leedokasele, et t�i selle s�nadesse, mida paljud tunnevad, aga ei julge �elda.

---

## L�hem variant

> Sibul on reklaam. Skandaal on t��riist. Kui sa tunned, et sind �hutati solvuma ilma p�ris p�hjuseta � see on infoh�gieeni �ppetund, mitte n�rkus. K�si alati: **kes v�idab minu vihast?**

---

## �ks lause (story / reply)

> �ra lase �elda ette, millal solvuda � see on infos�da, mitte reklaam.

---

## Mida me ei tee

- Ei v�ta poolt �hes politiits�jas (Lisa P � �ks inimene korraga).
- Ei r�nda venekeelset kogukonda ega eestikeelset kogukonda tervikuna.
- Ei jaga automaatselt OPORD linki kommentaarile (Lisa N �4b � orgaaniline levitamine).
- Ei kinnita fakte, mida me ise ei kontrollinud (reklaami sisu, parteide ametlikud seisukohad) � r��gime **mustrist**: kunstlik solvumine poliitilise kasu nimel.

---

## Seos lisadega (sisekasutus)

| Lisa | Seos |
|------|------|
| **AN** | Venekeelne info eraldi kanalil � mitte �ra l�igata, mitte �ra kasutada |
| **P** | Valideerimine: �loogiline, et tunned segadust" � enne loogikat |
| **BD** | OFNR: t�helepanek (mis reklaam tegelikult �tles) enne tunnet |
| **01** | Infoh�gieen � kes v�idab emotsioonist? |
| **T** | Poliitilised vektorid � mitte ainult �ks nimi |

---

*Kommunikatsioon � Leedokas / Rannarootsi. Uuendatud 26. juuli 2026.*
