# Vastus Rein Urvasile � eripension ja kaitsekulutused (Facebook)

**Kontekst:** Rein Urvas jagab ERR artiklit: *�Kaitseministeerium ei toeta tegevv�elaste eripensioni taastamist"*. Tema s�num: kaitsekulu artikkel t�usis, aga eelarve ikkagi ei soosi p�ris kaitsjate toetamist.  
**Allikad OPORD-is:** Lisa T (�6�7, H4), OPORD KPI-tabel, Lisa K �3.2 (KV muster), Lisa I (tagasiside).  
**Toon:** aus, mitte isiklik r�nnak � s��distame s�steemi ja otsuste ahelat, mitte �ksikut inimest.

---

## Soovitatav vastus (Facebooki kommentaar � kopeeri)

> Rein, sul on �igus m�rkida vastuolu.
>
> Kaitsekulu **protsent** t�useb � aga see ei t�henda automaatselt, et **p�ris kaitsja** (tegevv�elane, veteran, pere) v�idab.
>
> P�ris p�hjus on minu hinnangul kahekordne:
>
> **1. Pensioni- ja sotsiaalfond on aastaid kuivanud halbade otsuste t�ttu.** Nullsummam�ng: kui �ks rida (relvastus, hanke, SKP-protsent) kasvab, tuleb see mujalt �ra v�tta. Eripensioni taastamine n�uab raha, mida riik on juba �ra kulutanud teistesse prioriteetidesse � mitte alati valedestest prioriteetidest, aga otsustes, kus **numbrid** (eelarve, NATO %) l�ksid **inimeste KPI-de** (pered, s�ndid, l�bip�lemine, lahkujad) ette.
>
> **2. Tagasiside ei j�ua �les.** �leval on �ksildane � v�ljalt tuleb signaal (�me vajame tuge"), aga s�steem kuuleb seda kui kulurea probleemi, mitte usalduse ja j�tkusuutlikkuse probleemi. Kui tegevv�elane v�i veteran �tleb ausalt, mis ei t��ta, j�uab see harva otsuseni enne, kui juba tehakse j�rgmine �m�istlik tol hetkel" kompromiss.
>
> Tulemus: **kaitsekulu artikkel suureneb, aga kaitsja tunneb end ikka teisej�rgulisena.** See ei ole ainult �he ministri valik � see on ahel, kus fond on kuivanud ja info ei k�i ringi.
>
> Me ei vaja rohkem sloganeid. Me vajame: **show me the money** � kuhu t�pselt l�heb see t�us, ja **miks inimene, kes kannab koormust, ei saa seda tagasi pensioni ja toe n�ol.**
>
> Ait�h, et t�id selle lauale. Seda peab r��kima valjult.

---

## L�hem variant (kui kommentaar liiga pikk)

> Sul on �igus. Kaitse **%** t�useb, aga p�ris kaitsja ei pruugi v�ita � sest pensioni/sotsiaalfond on aastate halbade otsustega kuivanud (nullsummam�ng) ja **tagasiside v�ljalt �les ei j�ua**. Tulemus: suurem kaitsekulu rida, aga eripensioni taastamine �ei mahu". Probleem pole ainult �hes pressiteates � probleem on s�steemis, kus numbrid l�hevad inimeste ette.

---

## �ks lause (story / reply)

> Kaitsekulu t�us ? kaitsja v�it � fond on kuivanud halbade otsuste ja katkise tagasiside t�ttu.

---

## Mida me ei tee

- Ei s��ista �ksikut poliitikut v�i Urvasit.
- Ei v�ida fakte, mida ERR artikkel v�i eelarverida ei toeta � r��gime **mustrist** (Lisa T).
- Ei lisa automaatselt OPORD linki kommentaarile (orgaaniline levitamine � Lisa N �4b).
