# Lisa BD � Riiklik peegel: hindamisvorm riigisektoris

> **Lugeja saab:** kuidas tuua Operatsioon �Peegel" riiklikule tasandile � �htse hindamisvormi kaudu.  
> **Loe seda kui:** juhid asutust, osakonda, kooli, �ksust v�i riiklikku v�rgustikku.  
> **�ra loe kui:** oled esimene kord � alusta PEEGEL_TUUM.pdf; kriisis � Lisa H.

**Seotud:** Lisa AV (p�hivorm), Lisa BE (iga p�ev), Lisa I (Steiger), Lisa P (trauma-teadlik tagasiside), Lisa Q (austav keel), riigisektori austusjuhendid (Techno TLN eeskuju)

**Prindi:**

| Fail | Kasutus |
|------|---------|
| [PEEGEL_RIIK_HINDAMISVORM_PRINT.pdf](../PEEGEL_RIIK_HINDAMISVORM_PRINT.pdf) | **A4** � juht, kolleeg, all�ksuse juht (iga hindaja eraldi) |
| [PEEGEL_RIIK_PLANKETT.pdf](../PEEGEL_RIIK_PLANKETT.pdf) | **A3/A4 sein** � asutuse fuajee, personaliruum, �ppej�udude tuba |
| [PEER_HINDAMINE_RAHAKOTT.pdf](../PEER_HINDAMINE_RAHAKOTT.pdf) | **85�55 mm** � igap�evane kaaslase hindamine (Lisa BE) |
| [PEEGEL_HINDAMISVORM_PRINT.pdf](../PEEGEL_HINDAMISVORM_PRINT.pdf) | Pere / partner (Lisa AV � AV-PERE) |
| [SUHTE_HINDAMISE_TOOVIHIK_KATA_JA_LIIGU.pdf](../SUHTE_HINDAMISE_TOOVIHIK_KATA_JA_LIIGU.pdf) | **Suhte hindamise t��vihik** � sama taseme juhid (Lisa BF) |

Genereeri: `python3 generate_hindamisvorm_pdf.py`

---

## P�hiidee

Riigis on vaja **�htset peeglit** � mitte uut usu, vaid **sama k�simust igas asutuses**:

> **Kas ma usaldan seda inimest siis, kui keegi ei vaata?**

Riiklikul tasandil on peegel **hindamisvorm**. Vorm on plankett. Vestlus on protsess. **�ks tegu** on tulemus.

| Tase | Vorm | Sagedus |
|------|------|---------|
| **Iga p�ev** | **AV-PEER (Lisa BE)** | Iga olukord � alguses + sobival hetkel |
| **Kodu** | AV-PERE (Lisa AV) | 1� kuus |
| **Sama taseme juhid** | **Suhte hindamise t��vihik** (Lisa BF) | Kui suhe vajab parandamist / kvartal |
| **Meeskond / SOK** | AV-MEESKOND / AV-SOK | 1� kvartal |
| **Asutus / riigisektor** | **AV-RIIK** (see lisa) | 1� kvartal (juhtkond), 2� aastas (�lej��nud) |

---

## AV-RIIK � kellele

| Roll | Hindamine | Kes hindab (min 2) |
|------|-----------|-------------------|
| **Asutuse juht** (direktor, sekret�r) | Kvartalis | n�ukogu esindaja + personalijuht v�i �lemus |
| **Osakonnajuht / �ppejuht** | Kvartalis | juhtkond + 1 kolleeg |
| **Esiliin** (�petaja, ametnik, meditsiin, sotsiaal) | 2� aastas | vahetu �lemus + 1 kolleeg |
| **Tugiteenused** (IT, hooldus, turva) | 2� aastas | vahetu �lemus + kasutaja/esindaja |
| **Demonstraator / instruktor** | Kvartalis | 2 kolleegi + �ks alluv (kui on) |

**Reegel:** Iga hinnatav saab **v�hemalt 2** t�idetud vormi + **iserefleksiooni**. �ksi enda t�idetud leht ei loe.

---

## Riiklikud kriteeriumid (Lisa AV + 2 rida)

Lisa AV kuus kriteeriumi **pluss** riigisektori read:

| # | Kriteerium | K�simus |
|---|------------|---------|
| 1�6 | Initsiatiiv � Vastupidavus | (vt Lisa AV) |
| 7 | **Austus ja lugupidamine** | Kas ta suhtleb nii, et teine tunneb end v��rtustatuna? (ei solva, ei h�bista, ei ignoreeri) |
| 8 | **Turvalisus ja selgus** | Kas ta teatab ohtudest, j�rgib protsessi, ei j�ta p��rdumist vastuseta? |

**Usaldusk�simus (muutumatu):** Kas sa selle inimesega **luurele** l�heksid?

**Areng:** **K** Kasv | **H** Hoia | **P** Paus � mitte E/T/V, mitte avalik h�bistamine.

---

## Riiklik protsess (5 sammu)

| Samm | Tegevus | Vastutaja |
|------|---------|-----------|
| 1 | **Prindi** vorm � iga hindaja oma eksemplar | Personal / sekretariaat |
| 2 | **T�ida kirjalikult** enne vestlust � konkreetsed n�ited | Hindajad (eraldi) |
| 3 | **Vestle** 20�30 min (Lisa P � spordikommentaator) | Juht + hinnatav |
| 4 | **�ks tegu** j�rgmiseks kvartaliks | M�lemad kinnitavad |
| 5 | **Hoia konfidentsiaalselt** � mitte Slacki, mitte koridoris | Juhtkond |

**Seinale:** `PEEGEL_RIIK_PLANKETT.pdf` � fuajees v�i personaliruumis.  
**Koos:** riigisektori austusjuhend (Techno TLN sisekorra eeskirja loogika).

---

## Kus alustada (piloot)

| Prioriteet | Asutus | Miks |
|------------|--------|------|
| 1 | **Techno TLN** (�ks linnak) | ~6000 �ppijat, �hendamine, Y-p�lvkond, austusjuhend olemas |
| 2 | **Kaitseliit / KV koolitus�ksus** | Demonstraatorid, instruktorid, distsipliin + inimesekeskus |
| 3 | **�ks vallamaja v�i sotsiaalosakond** | Kodaniku kontakt, l�bip�lemine |
| 4 | **Aluste_kool (SOK)** | Demomehed juba checklisti peal � �leminek AV-SOK ? AV-RIIK |

**M��dik 90 p�eva:** Kas iga piloot�ksuses on 100% juhtkonnast l�binud 1 peegelvestluse (2 vormi + 1 tegu)?

---

## Faasid � riiklik levitamine

### Faas 0 � Standard (valmis)
- Lisa AV + Lisa BD
- PDF-id: `PEEGEL_RIIK_HINDAMISVORM_PRINT.pdf`, `PEEGEL_RIIK_PLANKETT.pdf`
- �ks lause: *Ennast keegi ise ei hinda. Peegel on hindamisvorm.*

### Faas 1 � Piloot (3 asutust, 6 kuud)
- Techno TLN + KV/Kaitseliit + �ks omavalitsus
- Igakuine raport: mis t��tab, mis triggerdas, �ks parandus

### Faas 2 � Sektorid (12 kuud)
- Haridus, tervis, sisejulgeolek, kohalikud omavalitsused
- Koolitaja-koolitajad (demonstraatorid) juhivad vormi, mitte loengut

### Faas 3 � Riiklik raamistik (24 kuud)
- Hindamisvorm osa arenguvestluse standardist avalikus teenistuses
- Seotud: austus ja turvalisus (sisekord), mitte eraldi �pehme projekt"

---

## Mida MITTE teha

| �ra tee | Miks |
|---------|------|
| Avalik pingerida | Trauma, kiusamine (Lisa S) |
| Vorm karistusena | Peegel ? kohtunik |
| Ainult HR-is | Peegel peab olema juhi t��riist |
| Ilma kirjata | Vestlus ununeb, moonutatakse |
| Ilma j�rgmise sammuta | Kriitika ilma teota |

---

## �ks lause riigile

> **Iga avaliku teenistuse juht ja esiliin teeb kvartalis kirjaliku peegli � ja vastab ausalt: kas ma usaldan seda inimest siis, kui keegi ei vaata?**

---

*Lisa BD � Riiklik peegel. T�iendab Lisa AV. Viimati uuendatud: 2026-07-30.*
