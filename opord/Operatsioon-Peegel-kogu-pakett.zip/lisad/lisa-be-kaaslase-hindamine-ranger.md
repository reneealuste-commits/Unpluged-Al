# Lisa BE � Kaaslase hindamine (Ranger School mudel)

> **Lugeja saab:** igap�evase, situatsioonip�hise peer evaluation'i � nagu Ranger Schoolis.  
> **Loe seda kui:** oled meeskonnas, koolis, �ksuses, peres v�i riigisektoris.  
> **�ra loe kui:** oled kriisis � Lisa H; formaalne kuu/kvartali peegel � Lisa AV.

## Olemasolev suhte hindamise vorm � �ra dubleeri

**Suhte hindamise t��vihik on juba olemas:** Lisa BF � `SUHTE_HINDAMISE_TOOVIHIK_KATA_JA_LIIGU.pdf` (SOK 24, *Kata ja liigu*, sama taseme juhid).

Lisa BE **ei ole** teine hindamisvorm. See on **mikropeegel**: igap�evane tagasiside, mis **toidab** t��vihikut (meeskond/SOK) v�i Lisa AV **AV-PERE** vormi (pere/partner). Kui t��vihik on olemas � kasuta BE-d ainult vahepealsete n�idete kogumiseks.

**Seotud:** Lisa BF (suhte hindamise t��vihik), Lisa AV (AV-PERE perele), Lisa Q (GOTWA, kata ja liigu), Lisa P (trauma-teadlik tagasiside), Lisa BD (riiklik vorm), Lisa N (demomees)

**Prindi:**

| Fail | Kasutus |
|------|---------|
| [PEER_HINDAMINE_RAHAKOTT.pdf](../PEER_HINDAMINE_RAHAKOTT.pdf) | **85�55 mm** � taskus, iga p�ev |
| [PEER_HINDAMINE_SOP_PRINT.pdf](../PEER_HINDAMINE_SOP_PRINT.pdf) | **A5** � sein / �ksuse kaust (millal ja kuidas) |

Genereeri: `python3 generate_hindamisvorm_pdf.py`

---

## P�him�te

Ranger Schoolis ei oota sa kolme kuud kuni keegi �tleb, mis valesti oli. **Iga p�ev. Iga olukord.** Kaaslased hindavad k�itumist **kohe** � alguses (ootused) ja sobival hetkel p�rast (tagasiside olukorrale).

| Ranger School | Peegel (BE) |
|---------------|-------------|
| Peer evaluation p�rast iga missiooni | **Situatsioonip�hine tagasiside** p�rast olukorda |
| Aus, otse, k�itumisele | Konkreetsed n�ited � mitte isiksuse sildid |
| �ksmeel meeskonnas | Usaldus kasvab, mitte hirm |
| Juht ei ole ainus hindaja | **Kaaslased** n�evad seda, mida �lemus ei n�e |

> **Ennast keegi ise ei hinda. Aga kaaslased n�evad su pimenurka � kui sa seda lubad.**

---

## Kolm kihti � �ks peegel

| Kiht | T��riist | Millal |
|------|----------|--------|
| **1. Igap�ev** | Lisa BE � kaaslase hindamine | Iga olukord, sobival hetkel |
| **2. S�gav** | Lisa BF � **suhte hindamise t��vihik** / Lisa AV (AV-PERE perele) | Kui suhe vajab parandamist / kuu (pere) |
| **3. Riiklik** | Lisa BD � AV-RIIK | Kvartal / 2� aastas (asutus) |

**BE ei asenda BF-d ega AV-d.** BE on **mikropeegel** � t��vihik (BF) v�i AV-PERE on **s�gav peegel**.

---

## Millal tagasisidet anda

### Alguses (enne olukorda)

Nagu GOTWA (Lisa Q) enne liikumist � viis vastust, et teadmatus ei kasvaks:

| Samm | K�simus |
|------|---------|
| 1 | **Mis on meie eesm�rk** selles olukorras? |
| 2 | **Kes mida teeb** � rollid selged? |
| 3 | **Kuidas suhtleme** � austav keel, konflikt? |
| 4 | **Mis on STOP** � kui keegi vajab pausi? |
| 5 | **Kus kohtume** p�rast � millal debrief? |

> L�hike. 60 sekundit. Mitte koosolek.

### P�rast olukorda (sobival hetkel)

| Sobib | Ei sobi |
|-------|---------|
| 5�15 min p�rast, kui keha rahunenud | Kohe karje keskel |
| Privaatselt v�i kahekesi | Avalikult grupis h�bistades |
| �Ma n�gin, et�" (Lisa P) | �Sa oled alati�" (silt) |
| �ks asi h�sti + �ks areng | Nimekiri vigadest |

**Reegel:** Kui keegi on triggeris � **Lisa P**: turvalisus enne loogikat. Debrief hiljem.

### Iga p�ev (v�hemalt �ks kord)

Demomees / kaaslane / kolleeg annab **v�hemalt �he** situatsioonip�hise tagasiside p�evas � v�i k�sib: *�Kas mul on midagi, mida sa n�gid ja mina ei n�inud?"*

---

## Kuidas tagasisidet anda (4 lauset)

```
1. OLUKORD:   "T�na koolitunnis / koosolekul / kodus kui�"
2. N�GIN:     "Ma n�gin, et sa�"  (konkreetne tegu)
3. M�JUTAS:  "See m�jutas mind / meeskonda nii, et�"
4. SOOVITUS: "J�rgmine kord v�iks�"  (�ks asi)
```

**Valikuline l�pp:** *�Kas ma usaldaksin sind selles olukorras uuesti?"* � mini-luure.

---

## Mida MITTE teha

| �ra | Miks |
|-----|------|
| Oota ametlikku vormi | Probleem kasvab |
| R��gi isiksusest | �Sa oled laisk" � trauma (Lisa S) |
| Anna tagasisidet kogukonnas | H�bi, mitte kasv |
| J�ta �tlemata, kui oht | Turvalisus trahib k�iki |
| Anna ainult negatiivset | Steiger: tugevus + areng |

---

## Taskukaart (PEER_HINDAMINE_RAHAKOTT)

T�ida l�hidalt � m�rkmik v�i �ks kaart p�evas:

```
OLUKORD: _________________________________
MIS TOIMIS: ______________________________
MIS V�IKS TEISITI: _______________________
�KS SOOVITUS: ____________________________
Luure sama olukorras uuesti?  ? Jah  ? Ei
```

Kui sama inimene kordub � kogu n�dalas, v�ta **suhte hindamise t��vihik** (Lisa BF) v�i **AV-PERE** (Lisa AV) ette.

---

## BE ? BF voog (sama taseme juhid / SOK)

| Samm | Millal | Mida teed |
|------|--------|-----------|
| 1 | **Iga p�ev** | BE taskukaart v�i 4 lause � �ks situatsioon |
| 2 | **Kui kordub** | T�ida **t��vihik** � Usalda/austa + Kuula/m�juta |
| 3 | **Enne vestlust** | Nelja k�simuse tegevusplaan (Lisa BF) |
| 4 | **Vestlus** | Lisa P; �ks tegu kolleegiga |

---

## BE ? AV voog (pere ja partner)

| Samm | Millal | Mida teed |
|------|--------|-----------|
| 1 | **Iga p�ev** | BE taskukaart v�i 4 lause � �ks situatsioon |
| 2 | **N�dala l�pus** | Vaata �le: mis kordus? Mis j�i �tlemata? |
| 3 | **Kuu l�pus** | T�ida **AV-PERE** (`PEEGEL_HINDAMISVORM_PRINT.pdf`) � BE m�rkmed ? konkreetsed read vormil |
| 4 | **Vestlus** | 15�20 min vormi p�hjal; �ks tegu j�rgmiseks kuuks |

**Meeskonnas (ametlik):** BE igap�ev, AV-MEESKOND kvartalis.

---

## Rakendus

| Kes | Miinimum |
|-----|----------|
| **Kaitseliit / KV kool** | Debrief p�rast iga treeningut; peer card instruktorile |
| **Techno TLN** | �petaja ? �petaja; �pilasesindus; t��koda |
| **Aluste_kool** | Demomees annab ja v�tab vastu iga p�ev |
| **Pere** | �ks aus lause p�evas � mitte ainult kriisi ajal |
| **Riigisektor** | Osakonna l�hike debrief p�rast rasket p�eva |

---

## �ks lause

> **Nagu Ranger Schoolis: iga p�ev, iga olukord � alguses selgus, l�pus aus tagasiside olukorrale. Peegel ei oota kvartalit.**

---

*Lisa BE � Kaaslase hindamine. T�iendab olemasolevat suhte hindamise t��vihikut (Lisa BF) ja pere vormi (Lisa AV). Viimati uuendatud: 2026-07-30.*
