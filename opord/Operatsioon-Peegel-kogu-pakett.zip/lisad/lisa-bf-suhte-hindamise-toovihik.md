# Lisa BF � Suhte hindamise t��vihik (Kata ja liigu)

> **Lugeja saab:** olemasoleva suhte hindamise t��vihiku � sama taseme juhtidele, kata ja liigu loogikaga.  
> **Loe seda kui:** oled SOK-is, demomees, meeskonna juht v�i kolleeg sama tasemel.  
> **�ra loe kui:** oled kriisis � Lisa H; pere/partner kuu peegel � Lisa AV (AV-PERE).

**Allikas:** Kodune t�� SOK 24 � *Kata ja liigu: sama taseme juhid*  
**Seotud:** Lisa N (Aluste_kool), Lisa Q �4 (kata ja liigu), Lisa BE (iga p�ev), Lisa AV (AV-PERE perele), Lisa I (Steiger)

**Prindi:**

| Fail | Kasutus |
|------|---------|
| [SUHTE_HINDAMISE_TOOVIHIK_KATA_JA_LIIGU.pdf](../SUHTE_HINDAMISE_TOOVIHIK_KATA_JA_LIIGU.pdf) | **4 lk t��vihik** � t�ida enne vestlust kolleegiga |

---

## P�him�te

> **Iga suhe, mis ei ole nii hea, kui see peaks olema, kujutab endast ohtu sinu meeskonnale ja missioonile.**

Mida paremad on suhted kolleegidega, seda paremini saad neid juhtida. T��vihik aitab **tuvastada** tasakaalust v�ljas suhte, **m�ista** oma rolli ja **luua tegevuskava** � mitte s��distada.

| Kata ja liigu (Lisa Q) | T��vihik (BF) |
|------------------------|---------------|
| N�ed haava, kata, liigu | N�ed n�rka suhet kolleegiga, v�ta samm |
| Konkreetne tegu + aeg | Tegevusplaan nelja k�simusega |
| Ei oota palvet | K�sid abi, kuulad, lased m�jutada |

---

## T��vihiku struktuur (4 lehek�lge)

### 1. Sissejuhatus

Usaldus ja austus sama taseme juhtide vahel � rollid, vastutus, selge suhtlus.

### 2. Usalda / austa

Vali �ks v�ide, mis k�ige paremini kirjeldab suhet **�he konkreetse kolleegiga** (neli astet � parimast n�rgimani). Kui oled tasakaalust v�ljas:

- V�ta �hendust � tutvu, tee koost��d
- Toeta kolleege, ole valmis appi minema
- Kontrolli ego/uhkust � ego on meeskondade tapja

### 3. Kuula / m�juta

Sama kolleeg � neli astet kuulamise ja m�jutamise kohta. Kui tasakaal on v�ljas:

- Kuula aktiivselt, luba end m�jutada
- �ra leiuta jalgratast � v�ta t�hus meetod kasutusele
- Toeta kolleegi ideid; eelista vaikimisi nende plaane

### 4. Tegevusplaan

Vasta neljale k�simusele:

1. Kirjelda t�psemalt probleem suhtlemisel
2. Kuidas see m�jutab seda isikut?
3. **Kuidas see on minu s��?**
4. Mida ma saan teha, et seda lahendada?

? **Tegevusplaan** (�ks konkreetne samm)

---

## Seos Lisa BE ja Lisa AV-ga

| Kontekst | Igap�ev (BE) | S�gav vorm |
|----------|--------------|------------|
| **Sama taseme juhid / SOK** | `PEER_HINDAMINE_RAHAKOTT.pdf` | **See t��vihik** � kui suhe vajab parandamist v�i kvartali peegel |
| **Pere / partner** | BE � �ks aus lause p�evas | Lisa AV � **AV-PERE** (`PEEGEL_HINDAMISVORM_PRINT.pdf`) |

**Lisa BE ei asenda t��vihikut.** BE kogub situatsioonid; t��vihik on **kirjalik peegel** enne vestlust kolleegiga.

**Voog (sama taseme juhid):**

1. **Iga p�ev** � BE: l�hike tagasiside v�i taskukaart (Lisa BE)
2. **Kui sama teema kordub** � v�ta t��vihik, t�ida Usalda/austa + Kuula/m�juta
3. **Enne vestlust** � neli k�simust + tegevusplaan
4. **Vestlus** � Lisa P (spordikommentaator); �ks tegu

---

## Rakendus

| Kes | Millal |
|-----|--------|
| **Aluste_kool (SOK)** | Kodune t�� 24; demomehed sama taseme juhtidena |
| **Kaitseliit / KV** | Sama taseme r�hma�lemad, instruktorid |
| **Riigisektor** | Osakonna juhid, kes ei ole �ksteise �lemused |
| **Techno TLN** | �petajate vaheline koost��, mitte ainult klassijuhataja |

---

## �ks lause

> **Suhte hindamise t��vihik on olemas � kasuta seda, mitte uut vormi. Iga p�ev BE, s�gav peegel t��vihikus.**

---

*Lisa BF � Suhte hindamise t��vihik (SOK 24). Viimati uuendatud: 2026-07-30.*
