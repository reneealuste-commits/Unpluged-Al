# Lisa K — Võrgustiku skeem, allüksuste ülesanded ja 

**Seotud:** Operatsioon „Peegel" — täielik organisatsiooniskeem 
**Eesmärk:** Kõik osalised nimeliselt — roll, eesmärk ja ülesanne; allüksuste kollektiivsed missioonid; kliendistatistika ja podcasti külalised. 
**Täiendab:** Lisa J (haridusasutused), Lisa I (juhtimine), [Renee Aluste profiil](renee-aluste-profiil.md)

> *Selgus aitab tegutseda. Iga inimene teab, kus ta asub ja mida temalt oodatakse.*

> *„Olen pannud tähele, et kui anda iga inimesele roll, eesmärk ja konkreetsed juhised, mida teha — siis ta tihti teebki seda."* — Renee Aluste

**Lisa K struktuur:** iga osalise juures on **roll**, **eesmärk** ja **konkreetsed ülesanded** — mitte ainult nimi nimekirjas.

> **LIHTSUS:** Sa ei pea kedagi siin tundma, et alustada. Alusta **PEEGEL_TUUM.pdf** või **Lisa AT**. See nimekiri on võrgustikule — mitte esimese lugemise kohaks.

## 1. Täielik organisatsiooniskeem

```
 ┌─────────────────────────────────────────────────────┐
 │ STRATEEGILINE TASE │
 │ Riho Ühtegi — rahva juhtimine, riigikaitse eeskuju │
 │ Rene Toomse — riigi/valitsuse tase, infosõda │
 │ Eerik Heldna — kriisireguleerimine │
 │ Elmar Vaher — RKIK, kaitseinvesteeringud │
 └──────────────────────────┬──────────────────────────┘
 │
 ┌───────────────────────┬───────────────────────┼───────────────────────┬───────────────────────┐
 │ │ │ │ │
┌────────▼─────────┐ ┌──────────▼──────────┐ ┌────────▼─────────┐ ┌─────────▼─────────┐ ┌────────▼─────────┐
│ KOORDINEERIMINE │ │ JUHTIMISKOOLITUS │ │ VANGLATEENISTUS │ │ HARIDUSTASE │ │ TEADVUSTUS │
│ Renee Aluste │ │ Priit, partnerid │ │ Ain Anslan │ │ (vt Lisa J) │ │ Lucas, Villido │
│ (vt eraldi prof) │ │ Martin Jõesaar │ │ Viru vangla │ │ Techno TLN, KVA, │ │ tantra, Pühali │
└────────┬─────────┘ │ Eerik, Louis, Robert │ └──────────────────┘ │ RaM, TVW Waldorf │ └────────┬─────────┘
 │ │ Elmar, võrgustik │ Montessori võrg. └─────────┬─────────┘ │
 │ ├──────────────────────┤ │ │
 │ │ Her Way (sõltumatu) │ │ │
 │ │ Supermängud (Tanel) │ │ │
 │ │ Pertinax (Ojaots) │ │ │
 │ └──────────┬───────────┘ │ │
 │ │ │ │
 │ ┌───────────────────┼───────────────────┬──────────────────────────────┘ │
 │ │ │ │ │
┌────────▼────▼───┐ ┌───────────▼──────────┐ ┌────▼─────────────┐ ┌────────────────▼──────────────────┐
│ KOHALIKUD │ │ VETERANID / TUGI │ │ PODCAST / Meedia │ │ VÕRGUSTIKU TOETAJAD │
│ Järvsoo (Kotkad) │ │ Kinnunen (veteranid) │ │ 24 episoodi │ │ Tegusad ettevõtjad (hajutatud) │
│ Ambros (Harku) │ │ Sillaste (supervis) │ │ jujutud.ee │ │ hajutatud ettevõtjad (vt 3.13) │
└──────────────────┘ └───────────────────────┘ └───────────────────┘ └───────────────────────────────────┘
```

**Põhipingutusüksus:** Iga Eesti kodanik — eriti lapsevanemad, mentorid ja kogukonna liidrid.

---

## 2. Operatsioon — mõõdikud ja tagasiside

**Allikas:** reneealuste.com, Apple Podcasts, RSS (uuendatud 2026)

### Operatsiooni mõõdikud

| Mõõdik | Väärtus | Märkus |
|--------|---------|--------|
| Käivitatud | 2026 | Kodanikualgatus — Renee Aluste |
| Lisa materjale | **50+** | OPORD + lisad A–BC |
| Juhtimiskoolituste kogemus | **300+** | Renee ja partnerite taust (isiklik) |
| Priit Lilleväli juhendamistunnid | **800+** | Individuaalne mentorlus |
| Podcast | **24+ episoodi** | reneealuste.com, jujutud.ee, YouTube @reneealuste |
| SOK kursused (Kaitseliit) | **6×** täiskursus | 240+ akadeemilist tundi igaüks |

### Kliendi tagasiside (valik)

| Nimi | Roll / kontekst | Tsitaadi tuum |
|------|-----------------|---------------|
| Raul Eamets | Klient | Praktiline juhtimine, mis töötab päriselus |
| Triin Limbach | Klient | Selgus ja vastutus meeskonnas |
| Jonna Pechter | Klient | Extreme Ownership põhimõtted muutsid juhtimist |
| Kairo Sulbi | Klient | Koolitus, mis jäi meelde ja rakendus |
| Renno Reinurm | Klient | Aus, otsekohene, tulemuslik |
| Hannes Aaresild | Klient | Meeskonna sidusus ja distsipliin |
| Kristjan Kookmaa | Klient | Juhtimine kriisiolukorras |

*Täielikud tsitaadid: reneealuste.com/meist*

---

## 3. Allüksuste kollektiivsed ülesanded

### 3.1 Strateegiline tase

**Eesmärk:** Ühendada riiklik julgeolek, kodaniku vastutus ja avalik sõnum ilma propaganda keeleta.

| Ülesanne | Kirjeldus |
|----------|-----------|
| 1 | Avalik sõnum: riigikaitse algab kodus |
| 2 | Poliitiline ja ühiskondlik dialoog perede toetusest |
| 3 | Ühendavad narratiivid, mis ei lõhu, vaid ehitavad |
| 4 | Kriisikommunikatsiooni standardid (koos StratKom-iga) |

### 3.2 Operatsiooni koordineerimisüksus (Renee Aluste)

**Eesmärk:** Koordineerida sõnumit, võrgustikku ja tegevust rahva tasandil.

| Ülesanne | Kirjeldus |
|----------|-----------|
| 1 | Sõnumite koordineerimine ja levitamine |
| 2 | võrgustiku koolituste korraldamine võrgustikule |
| 3 | Isiklike lugude jagamine (autentsus) |
| 4 | Mõõdikute jälgimine (tagasiside kogukonnast) |
| 5 | **E-sliin** — suhtlus erinevate üksustega, kes parandavad olukorda (sageli sümptomite kaudu); ühendab **suure pildi** ja igapäevased tööriistad |
| 6 | Tuvastatud probleemide käsitlemine rahva taastamise juhises — lihtsad lahendused enne keerukaid |
| 7 | **KV muster:** vastutuse puudumine → koormus vähestele → läbipõlemine ja lahkumine; lahendus = kõik teevad oma osa + kiusamise ja vana juhtimisstiili lõpp (Lisa I) |

*Täielik profiil: [renee-aluste-profiil.md](renee-aluste-profiil.md)*

### 3.2b Margus Lõoke — Kaitseväe mustri tunnistaja

**Eesmärk:** Toomine Kaitseväe sisemise vaate operatsiooni planeeringusse — ilma ametliku statistikata, ausa tähelepanekuna.

| Ülesanne | Kirjeldus |
|----------|-----------|
| 1 | Jagada Reneelega tähelepanekut: **suur osa Kaitseväes töötavatest inimestest on diagnoositud ATH-ga** |
| 2 | Kinnitada e-sliini mustrit — struktuur, uni ja roll vs ainult sümptomi kustutamine |
| 3 | Toetada sõnumit: lihtsad tööriistad (Lisa H, Lisa I, Lisa P) enne keerukaid lahendusi |

> *Isiklik vaatlus, mitte epidemioloogiline väide. Renee dokumenteerib, sest see klapib suure pildiga.*

### 3.3 OÜ

**Eesmärk:** Praktiline juhtimiskoolitus — Extreme Ownership, vastupidavus, turvalisus.

| Ülesanne | Kirjeldus |
|----------|-----------|
| 1 | Ülima vastutuse koolitused ettevõtetele ja kogukondadele |
| 2 | Juhtimis- ja meeskonnakoolitused perede ja MTÜ-de juhtidele |
| 3 | Veebipõhised ja hübriidlahendused (2026 fookus: turvalisus) |
| 4 | LDAP programm — organisatsioonide juhtimisjoondamine |
| 5 | Mentorlus (Priit Lilleväli, võrgustiku partnerid) |

### 3.4 Naiste enesejuhtimise kogukond

**Eesmärk:** Naiste enesejuhtimine ja vastutus — eriti emadele ja juhtidele.

| Ülesanne | Kirjeldus |
|----------|-----------|
| 1 | Igakuised enesejuhtimise veebikohtumised |
| 2 | Extreme Ownership naiste kontekstis (naiste enesejuhtimise kogukond) |
| 3 | Kogukonna loomine — ausus, vastutus, tugi |

### 3.5 Laste Supermängud

**Eesmärk:** Noorte praktiline vastutus enne algoritmi.

| Ülesanne | Kirjeldus |
|----------|-----------|
| 1 | Laste Supermängud (7–12 a.) — vastutus, keskendumine |
| 2 | noorteprogramm programmid koolidele ja MTÜ-dele |
| 3 | Vanemate mentorlus: väike harjutus päevas |

### 3.6 MTÜ Team Pertinax

**Eesmärk:** Mereväe-kultuuriga meeskond — tugevad, eneseteadlikud ettevõtjad.

| Ülesanne | Kirjeldus |
|----------|-----------|
| 1 | ~20 liikme treeningud: juhtimine, meeskond, vastupidavus |
| 2 | Mereväe distsipliini levitamine tsiviilkanalisse |
| 3 | Ühised treeningud Renee Alustega ja võrgustikuga |

### 3.7 Vanglateenistus / Viru vangla

**Eesmärk:** Inimesekeskne juhtimine raskes keskkonnas — kriisivalmidus ja meeskonnakultuur.

| Ülesanne | Kirjeldus |
|----------|-----------|
| 1 | Juhtide koolitus Extreme Ownership põhimõtetel |
| 2 | Kriisivalmidus igapäevase töökultuurina (mitte dokument riiulil) |
| 3 | Koostöö juhtimiskoolituse partneritega — veebiseminarid, kogemuslood |
| 4 | Inimlik pealehakkamine ja keskkonna kujundamine juhi käitumisega |

### 3.8 Haridustase

**Eesmärk:** Noorte vastupanuvõime koolides — vt täielik nimekiri **Lisa J**.

### 3.9 Teadlikkuse tase

**Eesmärk:** Sügavam ärkvelolek — mitu kanalit, üks missioon.

| Ülesanne | Kirjeldus |
|----------|-----------|
| 1 | „Ava oma Silmad" taskuhääling (Lucas) |
| 2 | Practical Consciousness kursused (Villido) |
| 3 | Tantralaagrid ja festivalid (Earthchild, Skalkina, Sarmet, Saul) |
| 4 | Pühali taastumine looduses (Sõõrumaa) |

### 3.10 Kohalikud allüksused

| Üksus | Eesmärk |
|-------|---------|
| Noorte Kotkad (Järvsoo) | Isamaaline kasvatus, distsipliin, eeskuju noortele |
| Harku (Ambros) | Füüsiline vastupidavus, ju-jutsu, enesekaitse |

### 3.11 Veteranid ja tugi

| Üksus | Eesmärk |
|-------|---------|
| Eesti Kaitseväe Veteranid (Kinnunen) | Veteranide tugi, ausad lood, kogukond |
| Marge Sillaste | Supervisioon — inimeste juhtimine, mitte protsesside kontroll |

### 3.12 Üksus Aluste_kool (SOK — demomehed) — AKTIVEERITUD

**Aktiveerija:** Renee Aluste · **Kood:** `Aluste_kool` · **Deviis:** *EE · Sõnaga mõõga vastu* / *Verbo contra gladium* · **Täielik juhend:** Lisa N

| Ülesanne | Kirjeldus |
|----------|-----------|
| 1 | Loe sõduriõpik + Kaitseväe sisemäärustik (viisakus, rivikord) |
| 2 | Päevane checklist: **austa · kuula · usalda · ole mõjutatud · hooli** (1× päevas) |
| 3 | Katseta mis töötab — igakuine tagasiside |
| 4 | Iga SOK läbinu on **demomees** — näita eeskuju, ära ainult räägi |

**Liikmed:** SOK läbinud tunnevad ennast ise ära — avalikku nimekirja ei ole.

### 3.13 Hajutatud võrgustik (mitte SOK)

**Eesmärk:** Tegusad inimesed, kes tegutsevad sõltumatult — ilma tsentraalse käsuta, **omal maastikul**.

| Nimi | Roll | Maastik |
|------|------|---------|
| Martin Plaser | Maadlustreener | Füüsiline distsipliin |
| Nils Ratt | Kohalik eestvedaja | Kogukond |
| Priit Uuemaa | Mentor | Juhtimine, areng |
| Sverre Puustusmaa | Võrgustiku tugi | Sidemed |
| Marko Kaseleht | Kohalik tegija | Piirkondlik tegevus |
| Kaido Raudvere | Tegus ettevõtja | Hajutatud võrgustik |
| Robert Käsper | Meedik (18D), veteran | Kaitse, meditsiin, „Eriväelase jutud" |
| Margus Lõoke | Kaitseväe mustri tunnistaja | ATH-muster KV-s (isiklik tähelepanek); e-sliini tugi |

---

## 4. Osalised nimeliselt — roll, eesmärk, ülesanne

### 4.1 Strateegiline tase

#### Riho Ühtegi — Strateegiline juht

![Riho Ühtegi](images/profiles/riho-uhtegi.jpg)

- **Roll:** Strateegiline eeskuju ja rahvuslik juhtimisvisioon
- **Eesmärk:** Riigikaitse mõistmine inimeste, mitte tankide kaudu
- **Ülesanne:** Avalik sõnum perede ja kodaniku vastutusest; eeskuju ilma dominantsita

#### Rene Toomse — Riigi ja valitsuse tase

![Rene Toomse](images/profiles/rene-toomse.jpg)

- **Roll:** Strateegiline nõustaja; valitsuse ja kodaniku sild
- **Eesmärk:** Infosõja mõistmine riiklikul tasandil
- **Ülesanne:** Ühendavad narratiivid; infosõja teemad ilma bürokraatiata

#### Eerik Heldna — Kriisireguleerimine

![Eerik Heldna](images/profiles/eerik-heldna.jpg)

- **Roll:** Kriisireguleerimise koordineerimine; juhtimiskoolitaja (endine, 2023–2026)
- **Eesmärk:** Kodaniku valmisolek ja rolliselgus kriisis
- **Ülesanne:** Õppused, stsenaariumid, kriisikommunikatsiooni standardid

#### Elmar Vaher — Kaitseinvesteeringud

![Elmar Vaher](images/profiles/elmar-vaher.jpg)

- **Roll:** RKIK peadirektor; juhtimiskoolitaja; RaM Kool lapsevanem
- **Eesmärk:** Riiklik võimekus ja kodaniku vastutus ühes narratiivis
- **Ülesanne:** RKIK investeeringuloogika; kooli kriisivalmidus (vt Lisa J)

---

### 4.2 Operatsiooni koordineerimisüksus

#### Renee Aluste — Operatsiooni koordinaator

![Renee Aluste](images/profiles/renee-aluste.jpg)

- **Roll:** Eestvedaja ja peamine sõnumitooja; **e-sliin** — suur pilt üksuste vahel
- **Eesmärk:** Ühendada isiklik kogemus ja sõjaline distsipliin; viia juure lahendused sinna, kus sümptomeid kustutatakse
- **Ülesanne:** Koordineerimine, autentsus, võrgustiku juhtimine; tuvastatud probleemid → lihtsad tööriistad (see juhis); KV tähelepanek: vastutus, koormus, läbipõlemine, juhtimisstiil
- **Eraldi leht:** [renee-aluste-profiil.md](renee-aluste-profiil.md)

#### Margus Lõoke — Kaitseväe mustri tunnistaja

- **Roll:** Usalduslik teealune hääl; Kaitseväe sisemise mustri vaatleja
- **Eesmärk:** Toomine ATH-mustri tähelepanek operatsiooni konteksti (isiklik vaatlus)
- **Ülesanne:** Kinnitada Reneele: suur osa KV personalist on diagnoositud ATH-ga; toetada sõnumit, et lihtsad tööriistad on proovimist väärt

---

### 4.3 Toetavad partnerid (sõltumatud)


#### Vallo Arumäe — Starfish Academy

- **Roll:** Kaasasutaja; finantsvabaduse koolitaja
- **Eesmärk:** Rahatarkus, investeerimine, passiivne tulu
- **Ülesanne:** Koolitused, Investorite Sisering ([starfish.academy](https://www.starfish.academy))

#### BMI Executive Institute

- **Roll:** Rahvusvaheline business school (Baltikum / Saksamaa partnerlus)
- **Eesmärk:** Juhtide EMBA ja executive education
- **Ülesanne:** Kõrgharidus ettevõtjatele ([bmiinstitute.com](https://www.bmiinstitute.com))

#### BNI Eesti (Business Network International)

- **Roll:** Maailma suurim ärireferaalide võrgustik
- **Eesmärk:** Struktureeritud ärisoovitused ja usaldusväärne ettevõtjate kogukond
- **Ülesanne:** Igana nädalased koosolekud — BNI North Star Tallinn (reedeti, Nordic Hotel Forum) ja BNI One Tallinn (neljapäeviti, Radisson Blu Olümpia); president: Kerdu Lenear ([bni.ee](https://bni.ee))

#### Kerdu Lenear — Mindset Fitness

![Kerdu Lenear](images/profiles/kerdu-lenear.jpg)

- **Roll:** Founder & CEO; BNI North Star Tallinn president
- **Eesmärk:** Mõtteviisi treening sportlastele ja ettevõtjatele
- **Ülesanne:** STOP-tehnika, enesetakistus, meeskonna koolitused ([mindsetfitness.ee](https://mindsetfitness.ee))

#### Julian Maier — URBN TIGER (Saksamaa)

![Julian Maier](images/profiles/julian-maier.jpg)

- **Roll:** Breathwork ja mental fitness; e-Residency envoy
- **Eesmärk:** Stressi vähendamine, vaimne vastupidavus
- **Ülesanne:** Hingamispraktika ettevõtetele ja startup'idele ([urbntiger.com](https://urbntiger.com))

#### Äripäev — investeerimis- ja juhtimiskultuur

- **Roll:** Investeerimisraadio, konverentsid, tunnustused
- **Eesmärk:** Rahatarkuse ja hea juhtimise avalik esiletõstmine
- **Ülesanne:** Investor Toomase tund (teisipäeviti 11:00), Investor Toomase konverents, Aasta investor, Parim juht ([aripaev.ee/raadio](https://www.aripaev.ee/raadio))

#### Rahakratt — rahablogi

- **Roll:** Anonüümne rahablogija ja investor
- **Eesmärk:** Finantsvabadus ausalt ja humoorikalt
- **Ülesanne:** Blogi, Investor Toomas, kogukond ([rahakratt.rahajutud.ee](https://rahakratt.rahajutud.ee))

#### Heli Illipe-Sootak — Peakirjastaja, *Inimesekeskne juhtimine*

- **Roll:** Peakirjastaja — Rudolf Steiger, *Inimesekeskne juhtimine* (Operatsioon „Peegel" juhtimis-SOP)
- **Taust:** Raudhammas OÜ juhatuse liige; bioloogiaõpetaja (Audentes School); kirjastustegevuse kogemus
- **Eesmärk:** Hoida Steigeri raamat elus — et inimesekeskne juhtimine jõuaks igasse juhini, mitte ainult Kaitseväe riiulile
- **Ülesanne:** Raamatu peakirjastamine operatsioonis; seos Lisa I, Lisa Z (dominantse süsteemi vastu); ISBN 9985901274

#### Epp Kärsin — Teadlik intiimsus

- **Roll:** Yoni massaaži ja intiimsuse koolitaja; **Lisa AA** praktiline juhend
- **Eesmärk:** Häbist vabanemine; stressi vabastamine kehas; päris orgasmid, mitte teesklmine
- **Ülesanne:** [eppkarsin.com](https://www.eppkarsin.com) — **pane end kirja** yoni koolitusele (naised + mehed); tel **5362 8568**

#### Vanja Moves meeskond — Liikuvus ja vigastuste ennetus

- **Roll:** Mobility, rippumine 90 sek/päev, vigastuste ennetus — **Lisa AB**
- **Meeskond:** Vanja Moves · Moves Method · Moves Labs · Josh Fear + treenerid · [schoolofmobility.com](https://schoolofmobility.com)
- **Eesmärk:** *Stretching master is a surgeon without a knife* — liigu enne operatsiooni; alusta **tasuta** (YouTube, podcast, Skool)
- **Ülesanne:** Vaata @Movesmethod · Liitu skool.com/movesmethod · Rippu 90 sek päevas · Küsi linnalt rippumisribasid

#### Kristjan Liivamägi — Aasta investor 2022

- **Roll:** TalTech vanemlektor; KML Invest; ELi rahatarkuse saadik
- **Eesmärk:** Teaduspõhine investeerimisharidus
- **Ülesanne:** Loengud, raamatud (*Eraisiku rahandus*), Aasta investor 2022 ([rahaedu.ee](https://rahaedu.ee))

#### Marko Oolo — Aasta investor 2024

- **Roll:** Investor, ettevõtja; Exceli meister
- **Eesmärk:** Praktilised investeerimistööriistad
- **Ülesanne:** Exceli portfellitööriistad, läbipaistev teekond ([oolomarko.ee](https://oolomarko.ee))

#### Katri Teller — Blondcast

- **Roll:** Blondcast eestvedaja; endine Rahareede
- **Eesmärk:** Taskuhääling raha, tervise ja enesearengu teemadel
- **Ülesanne:** Delfi Tasku podcast; Aasta investor 2023

#### Robert Käsper — Meedik, veteran (hajutatud)

- **Roll:** Üksuse meedik (18D); Delfi „Eriväelase jutud"; tegutseb hajutatult omal maastikul
- **Eesmärk:** Sõjaväelase ja meediku kogemuse edasiandmine — kaitse ja meditsiin
- **Ülesanne:** Podcast; välismissioonide meediku kogemus; Renee Aluste teenistusaeg (nooremveebel vs nooremseersant)

#### Martin Jõesaar — Kaasasutaja

![Martin Jõesaar](images/profiles/martin-joesaar.jpg)

- **Roll:** Co-Founder; Euroopa kaitsevõrgustik
- **Eesmärk:** Rahvusvaheline mõjutus ja koostöö
- **Ülesanne:** EL kaitseuuendused; Youth OÜ; strateegiline arendus

#### Priit Lilleväli — Instruktor, juhendaja

![Priit Lilleväli](images/profiles/priit-lillevali.jpg)

- **Roll:** Juhtimiskoolitaja; Aasta koolitaja 2023
- **Eesmärk:** Vastutus ja taastumine ilma ohvriidentiteedita
- **Ülesanne:** 300+ koolitust; 800+ juhendamistundi; podcast

#### Louis Zezeran — Instruktor (2023–2025)

- **Roll:** Juhtimistreener (isiklik taust); inglisekeelne kanal
- **Eesmärk:** Juhtimine loomingulistes ja startup-tiimides
- **Ülesanne:** Frontline Podcast; 4 Laws of Leadership kursus

#### Martin Jõesaar — Kaasasutaja

- **Roll:** Kaitseliidu instruktor; sTARTUp Day logistika
- **Eesmärk:** Praktiline juhtimine tsiviil- ja reservstruktuuris
- **Ülesanne:** Koolitused; ürituste toetamine

#### Andrus Albi — Partner

- **Roll:** koostööpartner
- **Eesmärk:** Äriline arendus ja võrgustik
- **Ülesanne:** Koostöö ja klientide toetamine

#### Mia-Alexandra Aidla — Turundus

- **Roll:** Turundusspetsialist
- **Eesmärk:** sõnumi levitamine
- **Ülesanne:** sTARTUp Day; podcast; sotsiaalmeedia

#### Siim Kaskpeit — Tugi ja teenindus

- **Roll:** Head of Support and Service
- **Eesmärk:** Kliendikogemus ja protsessid
- **Ülesanne:** Operatiivne tugi koolitustele

---

### 4.4 Naiste enesejuhtimise kogukond

![Naiste enesejuhtimise kogukond](images/profiles/naiste-enesejuhtimine.jpg)

#### Age Leedo — Kaaslooja, instruktor

- **Roll:** Her Way programmi juht
- **Eesmärk:** Naiste enesejuhtimine
- **Ülesanne:** Veebiseminarid; kogukonna ehitamine

#### Aet Tammis — Instruktor

- **Roll:** Her Way instruktor
- **Eesmärk:** Praktiline vastutus naiste kontekstis
- **Ülesanne:** Treeningud ja veebikohtumised

#### Karin Pohla — Instruktor

- **Roll:** Her Way instruktor
- **Eesmärk:** Enesejuhtimine emadele ja juhtidele
- **Ülesanne:** Koolitused ja mentorlus

#### Kristin Kriibi — Podcast / kogukond

- **Roll:** naiste esindaja
- **Eesmärk:** Usaldus ja eeskuju
- **Ülesanne:** Podcast; kogukonna vestlused

#### Sille Martma — Podcast / kogukond

- **Roll:** naiste esindaja
- **Eesmärk:** Eneseusaldus ja autentsus
- **Ülesanne:** Podcast; enesearengu töötoad

---

### 4.5 noorteprogramm

#### Tanel Jäppinen — Tegevjuht

- **Roll:** Parenting Solutions OÜ juht; Laste Supermängud
- **Eesmärk:** Noorte praktiline vastutus
- **Ülesanne:** 7–12-aastaste programmid; vanemate mentorlus
- **Kontakt:** tanel.jappinen@reneealuste.com

---

### 4.6 MTÜ Team Pertinax

#### Aigar Ojaots — Kaasasutaja, juhatuse liige

- **Roll:** Mereväe-kultuuriga meeskonna eestvedaja (~20 liiget)
- **Eesmärk:** Eneseteadlikud, tugevad ettevõtjad
- **Ülesanne:** Treeningud; ühised sessioonid Renee Alustega
- **Kontakt:** MTÜ Team Pertinax (reg. 80634291)

---

### 4.7 Vanglateenistus

#### Ain Anslan — Viru vangla direktor

![Ain Anslan](images/profiles/ain-anslan.jpg)

- **Roll:** Viru vangla direktor (alates 01.11.2023); koostööpartner
- **Eesmärk:** Inimesekeskne juhtimine raskes keskkonnas; ühiskonna turvalisus
- **Taust:** Magistrikraad personalijuhtimises; 19+ aastat riigi julgeoleku ja siseturvalisuse sektoris (sh 4 aastat kaitseväes). Endine relvastatud üksuse, saateüksuse, avavangla ja tugevdatud järelevalve üksuse juht. Vanglaametniku teeneterist (2021); teenistusmedal 15 aasta eest (2023).
- **Ülesanne operatsioonis:**
 1. Juhtide koolitus juhtimispõhimõtetel — inimlik pealehakkamine ja sihikindlus.
 2. Kriisivalmidus igapäevase töökultuurina (koos Priit Lilleväliga — veebiseminar, YouTube „Viru Vangla kogemuslugu").
 3. Keskkonna kujundamine juhi käitumisega — murda mõtteviis „ma olengi selline".
 4. Siduda avalik sektor ja kodanikualgatuse juhtimiskultuur.

---


### 4.15 Võtmetegijad — demonstraatorid

#### Ülo Vooglaid
- **Roll:** Kodaniku-mõtleja eeskuju
- **Ülesanne:** Soovita *Elanikust kodanikuks* (tee B)
- **Kontakt:** ylo@vooglaid.org

#### Indrek Paal
- **Roll:** Mõttepäranda levitaja
- **Ülesanne:** *Vanaisa uued lood*; sidumine Vooglaidi nõusolekul
- **Kontakt:** sihtasutus@vooglaid.org

*Lisa AR*

### 4.8 Haridustase (kokkuvõte — vt Lisa J)

| Nimi | Asutus | Roll |
|------|--------|------|
| Ott Pärna | Techno TLN | Direktor |
| Birgit Vilgats | Techno TLN | Õppejuht |
| Andra Piirsalu | Techno TLN | Personalijuht |
| Ander Sile | Techno TLN | Inseneriharidus |
| Tõnu Armulik | Techno TLN | Arendusdirektor |
| Kristel Bankier | Techno TLN | Finants/partnerlus |
| Kristel Martis | Techno TLN | Turundus/kogukond |
| Toivo Pärnpuu | Techno TLN | IT |
| Mari Vavulski | Techno TLN | Muudatuste projektijuht |
| Johan-Elias Seljamaa | KVA | Rektor |
| Rainek Kuura | KVA | Õppeosakonna ülem |
| Indrek Ojasoo | KVA | Akadeemia veebel |
| Aarne Ermus | KVA | Juhtimise suund |
| Hannes Tamjärv | RaM Kool | Asutaja, nõukogu esimees |
| Sirje Toomla-Õige | RaM Kool | Direktor |
| Rein Rebane | RaM Kool | Direktor emeeritus |
| Katrin Rodi | RaM Kool | Pearaamatupidaja |
| Maarika Eha-Müller | RaM Kool | Personalijuht |
| Anneli Paat | RaM Kool | Infojuht |
| Helin Vaher | RaM Kool | Lapsevanem, kommunikatsioon |
| **Ave Osa** | **TVW Waldorf** | **Võtmeisik, holistiline tugi** |
| Kristina Šanin | TVW Waldorf | Kooli juhataja |
| Ruth Maria Roosi-Ott | Montessori võrgustik | AMI juhendaja, instituudi juhatus |
| Kerli-Kristi Allikvee | Montessori võrgustik | AMI juhendaja, võrgustiku sidumine |

*Täielikud profiilid ja fotod: **Lisa J***

---

### 4.9 Teadlikkuse tase

| Nimi | Roll | Eesmärk | Ülesanne |
|------|------|---------|----------|
| Katrin Lucas | „Ava oma Silmad" | Teadlikkus | Taskuhääling, kogukond |
| Ingvar Villido | Practical Consciousness | Teadlik muutus | Kursused, Lilleoru |
| Tiit Trofimov | Enesearengu teejuht | Emotsioonid, meeste ring | Meditatsioon, töötoad, raamat |
| Igor Earthchild | Tantrafestival | Keha avamine | Laagrid, festivalid |
| Bella Skalkina | Tantrafestival | Lähedus, energia | Töötoad, korraldus |
| Margus Sarmet | Tantra Tribe | Praktiline tantra | Laagrid, jooga |
| Kristiina Saul | Naiste ringid | Vaimne ärkamine | Töötoad, teraapia |
| Urmas Sõõrumaa | Pühali | Taastumine looduses | Puhkus, üritused |
| Epp Kärsin | Teadlik intiimsus | Häbist vabanemine, paaride lähedus | Koolitused, noorte loengud (eppkarsin.com) |
| Vanja Moves meeskond | Mobility, rippumine | Vigastuste ennetus, 90 sek/päev | YouTube @Movesmethod, schoolofmobility.com — **Lisa AB** |
| Kaia Kapsta-Forrester | Pere- ja paariteraapia | Tugev pere, kriis ennetus | IMAGO, PREP, raseduskriis (kaiakapsta.com) |
| Kert Grünberg | Trauma, hingamine | Keha taastumine, kaassõltuvus | TRE, regressioon (hingamistuba.ee) |
| Jure Biechonski | Transpersonaalne teraapia | Alateadlikud mustrid, psühhosomaatika | THA, hüpnoteraapia (teadlikmina.ee) |
| Andres Põhjala | Judo, noored | Füüsiline distsipliin, kogukond | Spordiklubi Do, Tartu (do.ee) |

*Profiilipildid: peamine OPORD*

---

### 4.10 Kohalikud allüksused

#### Peeter Järvsoo — Noorte Kotkad

- **Roll:** Rühma vanem
- **Eesmärk:** Noorte isamaaline kasvatus
- **Ülesanne:** Distsipliin, meeskond, eeskuju enne sotsiaalmeediat

#### Andrei Ambros — Harku piirkond

![Andrei Ambros](images/profiles/andrei-ambros.jpg)

- **Roll:** Ju-jutsu treener; endine SOG ülem
- **Eesmärk:** Füüsiline vastupanuvõime
- **Ülesanne:** Taktikaline Grupp; enesekaitse; laskmine

#### Andres Põhjala — Spordiklubi Do (Tartu)

- **Roll:** Judotreener; klubi asutaja ja juht
- **Eesmärk:** Noorte füüsiline distsipliin ja kogukond
- **Ülesanne:** Judo väärtused (austus, enesekontroll); 500+ liiget; Tartu aukodanik 2026

---

### 4.11 Veteranid ja tugi

#### Eero Kinnunen — Eesti Kaitseväe Veteranid

![Eero Kinnunen](images/profiles/eero-kinnunen.jpg)

- **Roll:** MTÜ juhatuse esimees
- **Eesmärk:** Veteranide tugi ja ausad lood
- **Ülesanne:** Kogukond; side tsiviilühiskonnaga (ekvv.ee)

#### Marge Sillaste — Supervisioon

- **Roll:** Supervisioon ja coaching
- **Eesmärk:** Inimeste juhtimine protsesside asemel
- **Ülesanne:** Juhtide tugi; Steigeri põhimõtted praktikas

#### Kaia Kapsta-Forrester — Pere- ja paariteraapia

- **Roll:** Integratiivne pere- ja paaripsühholoog; suhtekoolitaja
- **Eesmärk:** Tugev pere enne lagunemist; kriisitugi (sh raseduskriis)
- **Ülesanne:** IMAGO, PREP; Väärtustades Elu SA; Lisa E, F, H suunamine

#### Epp Kärsin — Teadlik intiimsus

- **Roll:** Teadliku seksuaalsuse koolitaja (Amare Luna OÜ)
- **Eesmärk:** Intiimsus ja lähedus ilma häbi ja tabuta
- **Ülesanne:** Paarid, noored, ettevõtted; täiendab tantravõrgustikku ja pere rindejoont

#### Kert Grünberg — Trauma ja taastumine

- **Roll:** Holistiline regressiooniterapeut (Hingamistuba OÜ)
- **Eesmärk:** Trauma vabastamine kehas; eneseväärtus
- **Ülesanne:** TRE, rebirthing, kaassõltuvus; Lisa F, H

#### Jure Biechonski — Transpersonaalne teraapia

- **Roll:** Psühhhoterapeut; Teadlik Mina kooli juht
- **Eesmärk:** Alateadlikud mustrid; keha-meele tervendamine
- **Ülesanne:** THA, hüpnoteraapia; sügavam tase kui üldine eneseabi

---

### 4.12 Võrgustiku toetajad

| Nimi | Roll | Ülesanne |
|------|------|----------|
| Martin Plaser | Maadlustreener; hajutatud ettevõtja | Füüsiline distsipliin noortele |
| Nils Ratt | Tegus ettevõtja; hajutatud võrgustik | Kohalik eestvedamine |
| Priit Uuemaa | Tegus ettevõtja; hajutatud võrgustik | Mentorlus |
| Sverre Puustusmaa | Tegus ettevõtja; hajutatud võrgustik | Võrgustiku tugi |
| Marko Kaseleht | Tegus ettevõtja; hajutatud võrgustik | Kohalik tegevus |
| Kaido Raudvere | Tegus ettevõtja; hajutatud võrgustik | Kohalik tegevus |
| Peep Vain | Koolitaja (Vain & Partners) | Juhtimine, motivatsioon, enesemääramine |
| Alar Ojastu | Koolitaja, autor | *Ratsionaalne emotsionaalsus*; emotsioonid ja juhtimine |
| Tiit Trofimov | Enesearengu teejuht | Emotsioonid, meeste ring, meditatsioon (tiittrofimov.ee) |
| Epp Kärsin | Amare Luna / eppkarsin.com | Yoni koolitus, intiimsus — **Lisa AA**; pane end kirja |
| Vanja Moves meeskond | vanjamoves.com / movesmethod.com | Mobility, rippumine 90 sek — **Lisa AB**; tasuta YouTube |
| Kaia Kapsta-Forrester | Pere- ja paaripsühholoog | IMAGO, PREP, raseduskriis (kaiakapsta.com) |
| Kert Grünberg | Holistiline regressiooniterapeut | Trauma, TRE, kaassõltuvus (hingamistuba.ee) |
| Jure Biechonski | Transpersonaalne psühhhoterapeut | THA, hüpnoteraapia (teadlikmina.ee) |
| Andres Põhjala | Judotreener, Spordiklubi Do | Noored, distsipliin, Tartu (do.ee) |
| Ruth Maria Roosi-Ott | AMI Montessori juhendaja | Instituudi juhatus; lapse õppija-identiteet (Lisa J §5) |
| Kerli-Kristi Allikvee | AMI Montessori juhendaja | Montessori võrgustik üle Eesti (Lisa J §5) |
| Sina ja Mina (Gordon) | Lapsevanemate koolitus | Gordoni suhtlustreening (sinamina.ee) |
| Tallinna Perekeskus | „Imelised aastad" | Vanemlusprogramm 3–8-aastaste laste vanematele (pk.ee) |
| PAPSID.EE | Illimar Pilt, Kristo Tuurmann | Tugevate isade kasvatamine; koolitused, töötoad; **Papside laager** (papsid.ee/papside-laager) |
| Starfish Academy | Vallo Arumäe | Finantskirjaoskus, investeerimine (starfish.academy) |
| BMI Executive Institute | Euroopa õppejõud (sh Saksamaa) | Juhtide EMBA, executive education (bmiinstitute.com) |
| BNI Eesti | Kerdu Lenear (North Star president) | Ärireferaalid, ettevõtjate võrgustik (bni.ee) |
| Kerdu Lenear | Mindset Fitness | Mõtteviis, mindset koolitused (mindsetfitness.ee) |
| Julian Maier | URBN TIGER (Saksamaa) | Breathwork, vaimne fitness (urbntiger.com) |
| Äripäev | Investor Toomas, börsitoimetus | Investeerimisraadio, Aasta investor, Parim juht (aripaev.ee/raadio) |
| Rahakratt | Rahablogi | Finantsvabadus, aus blogi (rahakratt.rahajutud.ee) |
| Heli Illipe-Sootak | Raudhammas OÜ | Peakirjastaja — *Inimesekeskne juhtimine* (Steiger, Lisa I) |
| Kristjan Liivamägi | TalTech, KML Invest | Aasta investor 2022, rahatarkus (rahaedu.ee) |
| Marko Oolo | Investor, Excel | Aasta investor 2024, portfellitööriistad (oolomarko.ee) |
| Katri Teller | Blondcast | Aasta investor 2023, taskuhääling (tasku.delfi.ee) |
| Robert Käsper | Meedik (18D), veteran; hajutatult | Eriväelase jutud; kaitse ja meditsiin |
| Margus Lõoke | KV mustri tunnistaja | ATH-diagnostika muster KV-s (isiklik tähelepanek); e-sliini tugi |

---

## 5b. Etapp LIHTSUS ja kodaniku identiteet (vt Lisa M)

**Faas V:** *„Kui meeskond ei tea plaani, siis nad ei saa ju seda täita!"*

Iga kodanik: Tony Robbinsi 5 sammu, manifest peegli ees, kodaniku vanne (Renee Aluste). Täielik juhend: **Lisa M**.

---

## 5. Frontline podcast — kõik episoodid ja külalised

**Kanalid:** Apple Podcasts, Spotify, YouTube (@reneealuste), jujutud.ee, RSS 
**Episoode:** 24 (2024–2025)

| # | Pealkiri | Osalised / külalised |
|---|----------|----------------------|
| 1 | Kuidas juhtida nii, et kõigil oleks lihtne hästi töötada? | Priit Lilleväli, **Kai Saard** (PARE) |
| 2 | Mis on juhtimiskoolitus? sTARTUp Day 2025 | Priit Lilleväli, Mia-Alexandra Aidla |
| 3 | Läbi katsumuste eneseusalduseni (naiste kogukond) | Sille Martma, Kristin Kriibi |
| 4 | Kuidas saavutada usaldus ja olla hea eeskuju? (naiste kogukond) | Sille Martma, Kristin Kriibi |
| 5 | Personal Productivity — Lead Yourself | Louis Zezeran, **Boris Ümarik** (Produktiivsusklubi) |
| 6 | Lessons from Estonia's top national security leaders | Robert Käsper, Louis Zezeran; viited: **Hanno Pevkur**, **Riho Terras**, **Enn Adoson** |
| 7 | Freedom, War, Occupation — Estonian history | Remo Ojaste, Eerik Heldna |
| 8 | The 4 Laws of Leadership | Louis Zezeran |
| 9 | How to Prepare for a Crisis? | Louis Zezeran, **Janis Vanags** (CIREN) |
| 10 | Kuidas luua lapsega hea suhe? | võrgustiku partnerid |
| 11 | Suhete loomine kui pikk mäng (The Debrief) | Priit Lilleväli |
| 12 | Is EVERYTHING my problem? (The Frontline) | Remo Ojaste, Louis Zezeran |
| 13 | Life as an Estonian cop in the 90s | Eerik Heldna, Louis Zezeran |
| 14 | How to Rehearse for Tough Situations | Louis Zezeran, Remo Ojaste |
| 15 | What it takes to be a US Army Ranger | **Renee Aluste**, Louis Zezeran |
| 16 | 4 Steps to Improve Leadership | Remo Ojaste, Louis Zezeran |
| 17 | Theory is boring — train as you fight | Robert Käsper, Louis Zezeran |
| 18 | A Typical Day in Afghanistan | Priit Lilleväli, Louis Zezeran |
| 19 | Leadership Lessons from Comedy Estonia | Louis Zezeran |
| 20 | Haara initsiatiiv | Martin Jõesaar |
| 21 | Uju või upu — Lauri „Doc" Lemming | **Lauri „Doc" Lemming** |
| 22 | Läbi raskuste edasi — Tõnu Sillaots | **Tõnu Sillaots** |
| 23 | Aga miks mina? — Martin Siimann | **Martin Siimann** |
| 24 | „Lahinguväljal" enne ajateenistust — Priit Lilleväli | Priit Lilleväli |
| 25 | Juhtimine, ego, alandlikkus — Eerik Heldna | Eerik Heldna, Remo Ojaste |

### Podcasti väliskülalised (kokkuvõte)

| Nimi | Kontekst | Operatsioonis väärtus |
|------|----------|----------------------|
| Kai Saard | Personalijuhtimine (PARE) | Lihtne juhtimine, selgus |
| Boris Ümarik | Produktiivsusklubi | Isese juhtimine, fookus |
| Janis Vanags | Kriisijuhtimine (CIREN) | Kriisivalmidus kodanikule |
| Lauri „Doc" Lemming | Lastekirurg, veteran | Alandlikkus, vastupidavus |
| Tõnu Sillaots | Veteran, päästja | Elu pärast kaotust |
| Martin Siimann | Reservohvitser | „Tee ära" mentaliteet |
| Hanno Pevkur | Kaitseminister | Riiklik julgeolek (viide ep 6) |
| Riho Terras | Kindral (res.) | Strateegiline kogemus (viide ep 6) |
| Enn Adoson | Kaitseväe vanemveebel | Meeskonna kultuur (viide ep 6) |

---

## 6. Kiirviited

| Teema | Lisa / fail |
|-------|-------------|
| Renee Aluste eraldi profiil | `renee-aluste-profiil.md` |
| Haridusasutused | `lisa-j-haridusasutuste-juhtkonnad.md` |
| Juhtimine (SOP) | `lisa-i-inimesekeskne-juhtimine.md` |
| Kriis isale | `lisa-h-kiirjuhend-kriisis-isale.md` |
| veeb | reneealuste.com, reneealuste.com |
| Podcast | jujutud.ee, @reneealuste |

---

*Lisa K täieneb, kui operatsiooniga liituvad uued allüksused või osalised. Järgmine samm: maakondlike kogukondade juhtide lisamine.*
