Tee C — pere tugevdamine.
