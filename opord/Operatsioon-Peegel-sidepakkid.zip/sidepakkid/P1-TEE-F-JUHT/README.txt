Tee F — juht / koolitus.
