# Lisa BG � Inimesekeskse juhtimise �ppekava

> **Lugeja saab:** programmi �levaate � eesm�rgid, moodulid, tasemed, l�petamise tingimused.  
> **Loe seda kui:** koolitaja, juht, haridusasutuse �ppejuht v�i demomees (tee D/F).  
> **�ra loe kui:** otsid �ksiku tunni materjali � vaata **Lisa BH** (ainekava).

**Operatsioon �Peegel"** | Steiger 1997 (ISBN 9985901274) � peakirjastaja **Heli Illipe-Sootak**  
**Seotud:** Lisa I (selgroog), Lisa BH (ainekava), Lisa N (demomees), Lisa J (koolid), PEEGEL_TEE_F

**Programmi nimi:** **Inimesekeskne juhtimine (IJK)** � *Menschenorientierte F�hrung* rakenduskursus

---

## 1. Programmi eesm�rk

Koolitada juhte, kes suudavad:

1. Juhtida **inimest**, mitte ainult protsessi v�i tulemust.
2. Luua **turvalise** keskkonna enne vastutuse ja distsipliini n�udmist.
3. Kasutada **dialoogi**, mitte monoloogi � hindamine, areng, konflikt.
4. Rakendada **roll + eesm�rk + juhis** ilma dominantsita.
5. Hoida meeskonda **V-formatsioonis** � rotatsioon, mitte �ksik l�bip�lemine.

> *V�itmine on tagaj�rg inimeste juhtimisele � mitte sunni tulemus.* � Steiger / Kert eess�na

---

## 2. Sihtr�hm

| R�hm | Taseme soovitus | M�rkus |
|------|-----------------|--------|
| **Kaitsev�gi / Kaitseliit** � noorem- ja kesktaseme juhid | K1�K3 | KV/KL �ppekavade t�iendus; Steiger on juba viidatud allikas |
| **Haridus** � koolijuht, �ppejuht, �petaja, mentor | K1�K2 | Techno TLN, KVA, Waldorf, Montessori (Lisa J) |
| **Riigisektor** � osakonnajuht, esiliin | K1�K2 | Koos austusjuhendiga (Techno TLN eeskuju) |
| **MT� / kogukond** � demomehed, SOK | K0�K2 | Tee D; l�petab demomehe sertifikaadiga (Lisa N) |
| **Ettev�te** � meeskonnajuht, HR | K1�K2 | 1-1 vestlused enne mass-koolitust |
| **Kodanik / pere** | K0 | PEEGEL_TUUM + Lisa H; ei n�ua formaalset l�petamist |

**Eeltingimus k�igile (v.a. K0):** l�binud **Lisa P** p�him�tted v�i K1 mooduli 1 (turvalisus) � *ilma selleta vastutus muutub sundimiseks*.

---

## 3. �ppekeel ja vorm

| Parameeter | Valik |
|------------|-------|
| **Keel** | eesti (primaarne); vene kanal eraldi (Lisa AN, Kiht 0) |
| **Vorm** | h�briid: kontakt�pe + praktikum + 1-1 juhendamine |
| **Grupi suurus** | max 16 (praktikum); 1-1 kohustuslik K2+ |
| **Pikkus** | 6 moodulit � 2 n�dalat = **12 n�dalat** (K1 t�isprogramm) |
| **Koormus** | ~4 t akadeemilist t��d n�dalas (kontakt 2 t + iseseisev 2 t) |
| **Maht** | **24 akadeemilist tundi** kontakti + 24 t iseseisvat = **48 t** (? 2 EAP) |

---

## 4. Tasemed (K0�K3)

```
K0 TUUM ??? K1 P�HI ??? K2 PRAKTIKA ??? K3 JUHENDAJA
 (1 p�ev)    (12 n�dalat)   (+ praktika)    (mentorlus)
```

| Tase | Nimetus | Maht | Tulemus |
|------|---------|------|---------|
| **K0** | Tuum | 1 p�ev / 4 t | Teadlikkus; PEEGEL_TUUM; suunab K1 v�i Lisa H |
| **K1** | P�hiprogramm | 12 n�dalat, 48 t | **IJK tunnistus** � 6 moodulit l�bitud |
| **K2** | Praktika | +8 n�dalat | **IJK praktik** � 3 reaalset juhtimisjuhtumit dokumenteeritud |
| **K3** | Juhendaja | individuaalne | **Demomees / juhendaja** � juhib K1 r�hma v�i 1-1 (Lisa N) |

**Reegel:** K2 praktika **ei asenda** 1-1 vestlusi. Mass-koolitus ilma isikliku kontaktita ei anna K2 l�petamist (OPORD kogemus S�durioskuste kursustega).

---

## 5. �ppekava struktuur � kuus moodulit

J�rjekord j�rgib operatsiooni selgroogu (Lisa I):

| # | Moodul | Steigeri samm | N�dalad | Lisa(d) |
|---|--------|---------------|---------|---------|
| **M1** | Turvalisus enne m�istust | � (eeltingimus) | 1�2 | P, H, S |
| **M2** | Enesetundmine ja palk enda silmas | 1 | 3�4 | I �2�3, R, AW |
| **M3** | Inimene ja faktorite anal��s | 2 + faktorid | 5�6 | I �4, S, V |
| **M4** | Kuulamine ja m�istmine | 4 + �5 | 7�8 | I �5, Q, P |
| **M5** | Dialoog, peegel ja hindamine | 5 | 9�10 | I �6, AV, BF, BE, I |
| **M6** | Roll, juhis ja V-formatsioon | 3 + 6 | 11�12 | K, N, Q, AT |

Detailne sisu: **Lisa BH** (ainekava).

---

## 6. �piv�ljundid (programmi l�ikes)

L�petaja suudab:

| # | V�ljund |
|---|---------|
| OV1 | Selgitada erinevust domineeriva ja inimesekeskse juhtimise vahel (Steiger, Kert) |
| OV2 | Kasutada spordikommentaatorit ja valideerimist enne otsust (Lisa P) |
| OV3 | Teha faktorite anal��si enne s��distamist v�i ATH-sildi (Steiger lk 32) |
| OV4 | Juhtida 1-1 vestlust: m�ista ilma n�ustumata ? selgitada ? �hine lahendus |
| OV5 | Rakendada roll + eesm�rk + juhis konkreetses meeskonnaolukorras |
| OV6 | Kasutada peegli t��riistu: BE (iga p�ev), BF/AV (s�gav), hindamisvestlus |
| OV7 | Planeerida V-formatsiooni � rotatsioon, asendaja, l�bip�lemise ennetus |
| OV8 | Tunnistada oma vigu ausalt (�palk enda silmas") ilma autoriteedi kaotamata |

---

## 7. Hindamine ja l�petamine

### K1 tunnistus

| Komponent | Kaal | Kirjeldus |
|-----------|------|-----------|
| Osalemine | 20% | min 80% kontaktist; puudumine asendatakse 1-1 juhendajaga |
| Refleksioonid | 20% | 6 l�hikest kirjalikku refleksiooni (�ks per moodul) |
| Praktikumi juhtumid | 30% | 3 rollim�ngu / juhtumianal��si r�hmas |
| L�put�� | 30% | **�ks reaalne juhtimisjuhtum** � faktorite anal��s + tegevuskava |

**L�vend:** 70% koondhinne; l�put�� peab sisaldama v�hemalt �hte Steigeri sammu rakendust.

### K2 praktik

- 3 dokumenteeritud juhtumit t��kohal / �ksuses (anon��mselt)
- Iga juhtumi puhul: turvalisus ? dialoog ? �ks tegu ? tagasiside
- Juhendaja kinnitab (Lisa N demomees v�i K3 juhendaja)

### K3 juhendaja

- L�binud K1 + K2
- Juhendanud v�hemalt �he K1 r�hma v�i 5� 1-1 juhendamist
- Kinnitab **Heli Illipe-Sootak** peakirjastaja v�i tema m��ratud juhendaja

---

## 8. Materjalid ja t��riistad

| Materjal | Kasutus |
|----------|---------|
| Steiger, *Inimesekeskne juhtimine* (1997/2011) | P�hiraamat � ISBN 9985901274 |
| Lisa I | Operatsiooni selgroog, kiire kaart |
| Lisa BH | Ainekava (tunnid, �lesanded) |
| PEEGEL_TUUM.pdf | K0 sissejuhatus |
| PEEGEL_TEE_F.pdf | Juhi tee |
| SUHTE_HINDAMISE_TOOVIHIK_KATA_JA_LIIGU.pdf | M5 praktika (Lisa BF) |
| PEEGEL_HINDAMISVORM_PRINT.pdf | M5 � AV-PERE / meeskond |
| PEER_HINDAMINE_RAHAKOTT.pdf | M5 � igap�evane peegel (Lisa BE) |

**Sidepakk:** P1-TEE-F-JUHT (juhtidele); P1-TEE-D-DEMO (demomeestele)

---

## 9. Rakenduspartnerid (piloot)

| Partner | Moodulid | Eesm�rk |
|---------|----------|---------|
| **Techno TLN** | M1�M6 juhtkonnale; M1�M2 �petajatele | Inimesekeskne �hendkooli kultuur |
| **Kaitsev�e Akadeemia / Kaitseliit** | M1�M6 | Steigeri j�tk; V-formatsioon |
| **Aluste_kool (SOK)** | K0 + M1 + M5 + M6 | Demomeeste pipeline (Lisa N) |
| **tuum / juhtimiskoolituse partnerid** | K1�K2 | �ri- ja MT� juhid |

**Piloodi m��dik (90 p�eva):** kas 80% l�petajatest on teinud v�hemalt �he dokumenteeritud 1-1 vestluse faktorite anal��siga?

---

## 10. �ppekorraldus

| Element | Reegel |
|---------|--------|
| **1-1 vestlused** | K1 l�petaja saab v�hemalt 1� juhendaja 1-1 (30 min) |
| **R�hma turvalisus** | Lisa P kriitiline reegel � ei h�bistata, ei avalikku pingerida |
| **Konfidentsiaalsus** | Juhtumid j��vad r�hma; anon��mne anal��s lubatud |
| **Kriis** | Kui osaleja on kriisis � suunatakse Lisa H; koolitus ei asenda abi |
| **LIHTSUS** | �ks samm korraga (Lisa AT); mitte k�ik 6 moodulit korraga elus |

---

## 11. Seos teiste programmidega

| Programm | Seos IJK-ga |
|----------|-------------|
| **Tugeva Isa seeria A�G** | A�C enne v�i paralleelselt K1; G p�rast K2 |
| **Lisa N (demomees)** | K2 l�petaja v�ib kanduda demomeheks |
| **Lisa BD (riiklik peegel)** | M5 t�iendus riigisektori juhtidele |
| **Extreme Ownership** | **Alles p�rast** M1�M4 � vastutus on samm 5 |
| **Steigeri seminarid (KV)** | IJK on struktureeritud j�tk 12-n�dalase vormiga |

---

## 12. Arendusfaasid

| Faas | Tegevus | T�htaeg |
|------|---------|---------|
| **0** | Lisa BG + BH valmis; pilootmaterjalid tr�kitud | Valmis |
| **1** | Piloot: 1 r�hm (12 inimest), Aluste_kool v�i tuum | 3 kuud |
| **2** | Techno TLN + 1 KV �ksus; juhendajad K3 | 6 kuud |
| **3** | Akadeemiline tunnustus (koost�� KVA / EBS) | 12 kuud |

---

## �ks lause

> **Inimesekeskse juhtimise �ppekava: 12 n�dalat, 6 moodulit � turvalisus enne vastutust, dialoog enne k�sku, inimene enne protsessi.**

---

*Lisa BG � IJK �ppekava. T�iendab Lisa I. Ainekava: Lisa BH. Viimati uuendatud: 2026-07-30.*
