# Lisa BH � Inimesekeskse juhtimise ainekava

> **Lugeja saab:** moodulite detailse sisu � teemad, tunnid, �lesanded, hindamine.  
> **Loe seda kui:** koolitad IJK programmi (Lisa BG).  
> **�ra loe kui:** otsid ainult programmi �levaadet � vaata **Lisa BG** (�ppekava).

**Operatsioon �Peegel"** | Steiger 1997 � **Lisa BG** �ppekava  
**Seotud:** Lisa I, P, Q, N, AV, BF, BE, AT

---

## �ldandmed

| V�li | V��rtus |
|------|---------|
| **Programm** | Inimesekeskne juhtimine (IJK) � K1 |
| **Maht** | 24 t kontakt + 24 t iseseisev = 48 t |
| **Mooduleid** | 6 � 2 n�dalat |
| **Kontakt�pe** | 2 t n�dalas (loeng 45 min + praktikum 75 min) |
| **P�hiraamat** | Steiger, *Inimesekeskne juhtimine* (lk viited allpool) |

---

## M1 � Turvalisus enne m�istust

**N�dalad 1�2** � **4 t kontakt** � Steigeri eeltingimus (mitte otsene peat�kk � operatsiooni j�rjekord)

### �piv�ljundid

- Selgitab, miks loogika triggeris ei tervenda
- Kasutab spordikommentaatorit (3�5 lauset)
- Tuvastab, millal suunata inimene Lisa H / professionaalse abi poole
- Ei alusta vastutuse v�i distsipliini n�udmist ilma turvalisuseta

### Teemad

| Tund | Teema | Sisu | Tunnid |
|------|-------|------|--------|
| 1.1 | Miks alustame siit | Operatsiooni 5 sammu; Steiger vs EO j�rjekord | 2 |
| 1.2 | Keha enne m�istust | van der Kolk kokkuv�te; pre-verbaalne reaktsioon (Lisa S) | 2 |

### Lugemine

- Lisa P � � KRIITILINE REEGEL, spordikommentaator
- Lisa S � kiusamine ja trauma (valikuline s�gavus)
- Lisa H � kui osaleja kriisis

### Praktikum

| �lesanne | Kirjeldus |
|----------|-----------|
| **P1.1** | Kirjuta �ks olukord, kus sa vastasid loogikaga � ja see ei t��tanud. � lk |
| **P1.2** | Rollim�ng: kolleeg on triggeris. Kasuta spordikommentaatorit � mitte �petamist |
| **P1.3** | T�ida Lisa N checklist punkt 1 (Austa) � refleksioon 5 lauset |

### Hindamine (M1)

Refleksioon 1 (� lk): *Mis muutus, kui ma ei parandanud kohe?*

---

## M2 � Enesetundmine ja palk enda silmas

**N�dalad 3�4** � **4 t kontakt** � Steiger lk 26�31, peat�kk 2

### �piv�ljundid

- Vastab ausalt v�hemalt 5-le Steigeri eneserefleksiooni k�simusele (lk 27)
- Tunnistab �he oma vea ilma h�bistamata
- Selgitab �palk enda silmas" ja selle seost usaldusega

### Teemad

| Tund | Teema | Steiger | Tunnid |
|------|-------|---------|--------|
| 2.1 | Tunne iseennast | lk 26�29; Sokrates; realistlik enesehinnang | 2 |
| 2.2 | Palk enda silmas | lk 30�31; Villiger; vigade tunnistamine | 2 |

### Lugemine

- Steiger lk 26�31
- Lisa I �2�3
- Lisa R � Renee tunnistus (kiusaja ? usaldus)

### Praktikum

| �lesanne | Kirjeldus |
|----------|-----------|
| **P2.1** | T�ida Steigeri k�simuste kataloog (lk 27) � min 8 k�simust, ausalt |
| **P2.2** | �ks lugu: millal sa n�gid palki enda silmas? R�hmas 3 min / inimene |
| **P2.3** | Kirjuta �ks vabandus v�i tunnistus, mida sa peaksid andma � v�i miks ei pea (aus anal��s) |

### Hindamine (M2)

Refleksioon 2: *�ks k�simus Steigeri kataloogist, mis mind tabas � ja mida ma teen teisiti.*

---

## M3 � Inimene ja faktorite anal��s

**N�dalad 5�6** � **4 t kontakt** � Steiger lk 29, 32�34

### �piv�ljundid

- Ei juhi ainult ametikohta � tunneb inimese muresid, kartusi, konteksti
- Teeb faktorite anal��si enne sildi panemist (oskamatus vs tahtetus)
- Anal��sib ka **positiivseid** tulemusi � miks see meeskond t��tab?

### Teemad

| Tund | Teema | Steiger | Tunnid |
|------|-------|---------|--------|
| 3.1 | Nimede taga on inimesed | lk 29; �veitsi uuring; �kliiniline juhtum" | 2 |
| 3.2 | Faktorite anal��s | lk 32�34; tulemus vs tegurid; positiivne anal��s | 2 |

### Lugemine

- Steiger lk 29, 32�34
- Lisa S � ATH silt kui �kliiniline juhtum"
- Lisa V � uni faktorina (n�ide)

### Praktikum

| �lesanne | Kirjeldus |
|----------|-----------|
| **P3.1** | Vali �ks �halb tulemus" � t�ida faktorite anal��si tabel (Lisa I) |
| **P3.2** | Vali �ks �hea tulemus" � miks see t��tas? 3 faktori |
| **P3.3** | Juhtumianal��s: KV/tsiviil n�ide � oskamatus v�i tahtetus? |

### Hindamine (M3)

Juhtumianal��s 1 (1 lk): faktorite tabel + soovitus juhile

---

## M4 � Kuulamine ja m�istmine

**N�dalad 7�8** � **4 t kontakt** � Steiger lk 35�37, sammud 4�5

### �piv�ljundid

- M�istab inimest **ilma n�ustumata**
- Rakendab 4-sammulist vastamist (arutan ? info ? seletan ? �hine lahendus)
- Kasutab GOTWA enne rasket vestlust (Lisa Q)

### Teemad

| Tund | Teema | Steiger | Tunnid |
|------|-------|---------|--------|
| 4.1 | M�ista ? n�ustu | lk 35�37; n�ited (personal, s�jakool) | 2 |
| 4.2 | Kuulamine ja side | samm 4; Lisa Q � h��l, GOTWA, kata ja liigu | 2 |

### Lugemine

- Steiger lk 35�37
- Lisa Q � �1�4 (GOTWA, kata ja liigu)
- Lisa P � valideerimine

### Praktikum

| �lesanne | Kirjeldus |
|----------|-----------|
| **P4.1** | Rollim�ng: kolleeg tahab puhkust � sa ei saa anda. 4 sammu |
| **P4.2** | GOTWA �hele p�evasele kontaktile � kirjalikult enne praktikat |
| **P4.3** | Kuulamispraktika: 10 min partner kuulab ilma n�uandmata |

### Hindamine (M4)

Refleksioon 3 + l�hike video/audio (valikuline): 2 min spordikommentaator

---

## M5 � Dialoog, peegel ja hindamine

**N�dalad 9�10** � **4 t kontakt** � Steiger samm 5�6; Lisa AV, BF, BE

### �piv�ljundid

- Juhib hindamisvestlust dialoogina � mitte monoloogina
- Kasutab olemasolevaid vorme: **BF t��vihik** (kolleegid), **AV-PERE** (pere)
- Rakendab BE igap�evast mikropeeglit ? s�gav vorm
- Vastab luurek�simusele: *kas ma usaldan seda inimest siis, kui keegi ei vaata?*

### Teemad

| Tund | Teema | Materjal | Tunnid |
|------|-------|----------|--------|
| 5.1 | Dialoog, mitte monoloog | Steiger samm 5; Lisa I (Steiger) | 2 |
| 5.2 | Peegli t��riistad | Lisa BF, AV, BE; BF ? BE voog | 2 |

### Lugemine

- Lisa I � Steigeri kuus sammast (kokkuv�te)
- Lisa BF � suhte hindamise t��vihik
- Lisa AV � AV-PERE / AV-MEESKOND
- Lisa BE � igap�evane peer

### Praktikum

| �lesanne | Kirjeldus |
|----------|-----------|
| **P5.1** | T�ida BF t��vihiku �ks osa (Usalda/austa) � enda ja �he kolleegi kohta |
| **P5.2** | Simuleeritud hindamisvestlus 20 min � vahetu tagasiside partnerilt |
| **P5.3** | BE taskukaart 5 p�eva � too �ks n�ide s�gavale vormile |

### Hindamine (M5)

Refleksioon 4 + t�idetud BF lehek�lg v�i AV-PERE mustand (konfidentsiaalne)

---

## M6 � Roll, juhis ja V-formatsioon

**N�dalad 11�12** � **4 t kontakt** � Steiger samm 3, 6; Lisa K, N, AT

### �piv�ljundid

- Annab roll + eesm�rk + juhis � konkreetselt, mitte �ole parem"
- Planeerib rotatsiooni � keegi ei veda igavesti ees
- Koostab **�he teo** plaani j�rgmiseks kuuks (Lisa AT)

### Teemad

| Tund | Teema | Materjal | Tunnid |
|------|-------|----------|--------|
| 6.1 | Roll, eesm�rk, juhis | Lisa I; Lisa K v�rgustik | 2 |
| 6.2 | V-formatsioon ja j�tkusuutlikus | Lisa I; l�bip�lemine; asendaja | 2 |

### Lugemine

- Lisa I � Roll + V-formatsioon
- Lisa N � demomehe checklist
- Lisa AT � �ks tegu

### Praktikum

| �lesanne | Kirjeldus |
|----------|-----------|
| **P6.1** | Kirjuta �hele alluvale/kolleegile: roll + eesm�rk + 3 juhist |
| **P6.2** | V-formatsioon: kes on sinu meeskonnas �ees" liiga kaua? Plaan rotatsiooniks |
| **P6.3** | L�put�� ettevalmistus (vt allpool) |

### Hindamine (M6)

**L�put��** (30% koondhinnest):

---

## L�put�� � juhend

| V�li | N�ue |
|------|------|
| **Pikkus** | 2�3 lk |
| **Sisu** | �ks **reaalne** juhtimisjuhtum (anon��mne) |
| **Struktuur** | 1) Olukord 2) Faktorite anal��s 3) Steigeri samm(ud) 4) �ks tegu 5) Tagasiside |
| **V�ltida** | Isikute nimed; s��distav keel; lahendus ilma dialoogita |

**N�idis k�simus:** *Kuidas ma rakendasin m�istmist ilma n�ustumata � ja mis muutus?*

---

## Iseseisev t�� (kokkuv�te)

| N�dal | T�� maht | Tegevus |
|-------|----------|---------|
| 1�2 | 4 t | Lisa P lugemine; P1 refleksioon |
| 3�4 | 4 t | Steiger lk 26�31; P2 kataloog |
| 5�6 | 4 t | Faktorite anal��s 2 juhtumit |
| 7�8 | 4 t | Lisa Q; GOTWA igap�ev |
| 9�10 | 4 t | BF/AV vorm; BE kaardid |
| 11�12 | 4 t | L�put�� kirjutamine |

---

## Hindamismaatriks (K1)

| Moodul | Refleksioon | Praktikum | Kaal moodulis |
|--------|-------------|-----------|---------------|
| M1 | R1 | P1.2 rollim�ng | 3% + 3% |
| M2 | R2 | P2.1 kataloog | 3% + 3% |
| M3 | � | Juhtumianal��s 1 | 10% |
| M4 | R3 | P4.1 rollim�ng | 3% + 3% |
| M5 | R4 | BF/AV mustand | 3% + 5% |
| M6 | � | P6.1�6.2 | 4% + 4% |
| **L�put��** | | | **30%** |
| **Osalemine** | | | **20%** |

---

## K2 praktika � t�iendav ainekava

| Juhtum | N�uded | Tunnid |
|--------|--------|--------|
| **J1** | Dokumenteeritud 1-1 vestlus; faktorite anal��s; �ks tegu | 8 t |
| **J2** | Hindamis- v�i peeglivestlus (BF v�i AV); tagasiside partnerilt | 8 t |
| **J3** | V-formatsiooni rakendus � rotatsioon v�i delegatsioon; refleksioon | 8 t |

Juhendaja kinnitab iga juhtumi (Lisa N demomees v�i K3).

---

## K0 tuum � 1-p�evane ainekava (valik)

| Tund | Teema | Tunnid |
|------|-------|--------|
| T1 | Mis on inimesekeskne juhtimine? Steiger + Kert | 1 |
| T2 | Turvalisus enne vastutust (Lisa P l�hiversioon) | 1 |
| T3 | �ks peegel p�evas + LIHTSUS (Lisa AT) | 1 |
| T4 | Kuhu edasi? Tee D/F, K1 registreerumine | 1 |

Materjal: PEEGEL_TUUM.pdf

---

## �ppej�u n�uded (K3)

| N�ue | Kirjeldus |
|------|-----------|
| Kogemus | L�binud K1 + K2; min 2 aastat juhtimiskogemust |
| Stiil | Trauma-teadlik (Lisa P); ei h�bista; dialoog |
| Kohustus | 1-1 juhendamine � min 30 min / osaleja / programm |
| Areng | Supervisioon 2� aastas (Heli Illipe-Sootak v�rgustik) |

---

## �ks lause

> **Ainekava: iga n�dal �ks Steigeri samm, �ks praktikum, �ks aus refleksioon � 12 n�dala p�rast juhid inimest, mitte ainult tulemust.**

---

*Lisa BH � IJK ainekava. �ppekava: Lisa BG. Viimati uuendatud: 2026-07-30.*
